// lib/services/ai_service.dart

import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:intl/intl.dart';
import '../models/models.dart';

class AiService {
  static const _baseUrl = 'https://api.openai.com/v1/chat/completions';
  static const _apiKey = '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';
  static const _model = 'gpt-4o';

  Future<Map<String, dynamic>> _callApi(String prompt, [String? key]) async {
    final effectiveKey = (key != null && key.isNotEmpty) ? key : _apiKey;
    final response = await http.post(
      Uri.parse(_baseUrl),
      headers: {
        'Content-Type': 'application/json',
        'Authorization': 'Bearer $effectiveKey',
      },
      body: jsonEncode({
        'model': _model,
        'max_tokens': 2000,
        'messages': [
          {'role': 'user', 'content': prompt}
        ],
      }),
    );

    if (response.statusCode != 200) {
      throw Exception(
          'API Error: ${response.statusCode} ${response.body}');
    }

    final data = jsonDecode(response.body);
    final content =
        data['choices'][0]['message']['content'] as String? ?? '';

    return {'content': content, 'raw': data};
  }

  Future<List<GeneratedSchedule>> generateSchedules({
    required List<Subject> subjects,
    required Map<String, List<TimeSlot>> availableSlots,
    required List<DateTime> blockedDates,
    required Constraints constraints,
    required String apiKey,
  }) async {
    final fmt = DateFormat('yyyy-MM-dd');
    final subjectData = subjects
        .map((s) => {
              'name': s.name,
              'topics': s.totalTopics,
              'proficiency': s.proficiency,
              'priority': s.priority.name,
              'examDate':
                  s.examDate != null ? fmt.format(s.examDate!) : null,
            })
        .toList();

    final slotsData = availableSlots.entries
        .where((e) => e.value.isNotEmpty)
        .map((e) => {
              'day': e.key,
              'slots': e.value
                  .map((sl) => {
                        'start':
                            '${sl.startTime.hour}:${sl.startTime.minute.toString().padLeft(2, '0')}',
                        'end':
                            '${sl.endTime.hour}:${sl.endTime.minute.toString().padLeft(2, '0')}',
                      })
                  .toList(),
            })
        .toList();

    final prompt = '''
You are an exam preparation scheduler. Generate 3 optimized study schedules.

Student profile:
${jsonEncode({
      'subjects': subjectData,
      'availableSlots': slotsData,
      'blockedDates': blockedDates.map((d) => fmt.format(d)).toList(),
      'constraints': {
        'maxContinuousMinutes': constraints.maxContinuousMinutes,
        'minBreakMinutes': constraints.minBreakMinutes,
        'dailyMinHours': constraints.dailyMinHours,
        'noStudyAfterHour': constraints.noStudyAfterHour,
        'customRules': constraints.customRules,
      }
    })}

Generate 3 schedules for the next 14 days starting from today ${fmt.format(DateTime.now())}.

Respond ONLY with valid JSON in this exact format, no markdown, no explanation:
{
  "balanced": {
    "title": "Balanced plan",
    "description": "Equal distribution across subjects with moderate daily hours.",
    "hoursPerDay": 4.0,
    "focusStrategy": "Rotate subjects daily with revision every 3 days.",
    "blocks": [
      {"date": "YYYY-MM-DD", "startHour": 9, "startMinute": 0, "endHour": 11, "endMinute": 0, "subjectName": "Mathematics", "type": "learn"},
      {"date": "YYYY-MM-DD", "startHour": 14, "startMinute": 0, "endHour": 16, "endMinute": 0, "subjectName": "Physics", "type": "learn"}
    ]
  },
  "aggressive": {
    "title": "Aggressive plan",
    "description": "Maximum daily hours with heavy focus on weak subjects.",
    "hoursPerDay": 6.0,
    "focusStrategy": "Double sessions on low-proficiency subjects.",
    "blocks": []
  },
  "relaxed": {
    "title": "Stress-free plan",
    "description": "Shorter sessions to avoid burnout, high-priority only.",
    "hoursPerDay": 3.0,
    "focusStrategy": "One subject per day, no evening sessions.",
    "blocks": []
  }
}

Rules:
- Only schedule on days matching availableSlots day names
- Skip blockedDates
- Skip examDates (mark them as exam days, no study)
- Respect maxContinuousMinutes and dailyMaxHours
- Include at least 10 blocks per schedule spread across the 14 days
- Balance subjects by priority (high priority gets more blocks)
- Include both "learn" and "revise" types
''';

    final result = await _callApi(prompt, apiKey);
    final content = result['content'] as String;

    final clean = content
        .replaceAll(RegExp(r'```json\s*'), '')
        .replaceAll(RegExp(r'```\s*'), '')
        .trim();

    final parsed = jsonDecode(clean) as Map<String, dynamic>;

    return _parseSchedules(parsed, subjects);
  }

  List<GeneratedSchedule> _parseSchedules(
      Map<String, dynamic> data, List<Subject> subjects) {
    final scheduleKeys = {
      'balanced': ScheduleType.balanced,
      'aggressive': ScheduleType.aggressive,
      'relaxed': ScheduleType.relaxed,
    };

    return scheduleKeys.entries.map((entry) {
      final key = entry.key;
      final type = entry.value;
      final d = data[key] as Map<String, dynamic>;
      final blocks = (d['blocks'] as List? ?? []).map((b) {
        final subjectName = b['subjectName'] as String;
        final subject = subjects.firstWhere(
          (s) => s.name == subjectName,
          orElse: () => subjects.isNotEmpty
              ? subjects.first
              : Subject(id: '', name: subjectName),
        );
        return StudyBlock(
          id: DateTime.now().millisecondsSinceEpoch.toString() +
              subjectName,
          date: DateTime.parse(b['date']),
          startTime: TimeOfDay(
              hour: b['startHour'], minute: b['startMinute']),
          endTime:
              TimeOfDay(hour: b['endHour'], minute: b['endMinute']),
          subjectId: subject.id,
          subjectName: subjectName,
          type: b['type'] == 'revise' ? StudyType.revise : StudyType.learn,
        );
      }).toList();

      return GeneratedSchedule(
        type: type,
        title: d['title'] ?? type.name,
        description: d['description'] ?? '',
        hoursPerDay: (d['hoursPerDay'] as num?)?.toDouble() ?? 4.0,
        focusStrategy: d['focusStrategy'] ?? '',
        blocks: blocks,
      );
    }).toList();
  }

  Future<Map<String, dynamic>> analyzeScores({
    required List<Subject> subjects,
    required List<ExamScore> scores,
    String apiKey = '',
  }) async {
    final scoreData = scores
        .map((s) => {
              'subject': s.subjectName,
              'score': s.score,
              'currentPriority': subjects
                  .firstWhere((sub) => sub.id == s.subjectId,
                      orElse: () => Subject(id: '', name: s.subjectName))
                  .priority
                  .name,
            })
        .toList();

    final subjectNames = subjects.map((s) => s.name).toList();

    final prompt = '''
Analyze these exam scores and provide a concise 3-4 line study strategy recommendation.
Then provide updated priorities in JSON.

Scores: ${jsonEncode(scoreData)}

Rules:
- below 50% → high priority
- 50-75% → medium priority  
- above 75% → low priority

Respond with your analysis text, then on a new line:
JSON_PRIORITIES: {"priorities": {${subjectNames.map((n) => '"$n": "high"').join(', ')}}}

Be encouraging but realistic. Keep analysis to 3-4 sentences.
Replace the priority values (high/medium/low) based on scores above.
''';

    final result = await _callApi(prompt, apiKey);
    final content = result['content'] as String;

    final jsonMatch =
        RegExp(r'JSON_PRIORITIES:\s*(\{.*\})', dotAll: true)
            .firstMatch(content);

    Map<String, String>? priorities;
    if (jsonMatch != null) {
      try {
        final jsonStr = jsonMatch.group(1)!;
        final parsed = jsonDecode(jsonStr) as Map<String, dynamic>;
        final pMap = parsed['priorities'] as Map<String, dynamic>?;
        if (pMap != null) {
          priorities = pMap.map((k, v) => MapEntry(k, v.toString()));
        }
      } catch (_) {}
    }

    final analysisText = content
        .replaceAll(RegExp(r'JSON_PRIORITIES:.*', dotAll: true), '')
        .trim();

    return {
      'text': analysisText,
      'priorities': priorities,
    };
  }
}

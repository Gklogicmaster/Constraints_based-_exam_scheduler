// lib/services/scheduler_engine.dart

import 'package:flutter/material.dart';
import 'package:uuid/uuid.dart';
import '../models/models.dart';

const _uuid = Uuid();

const _priorityWeights = {
  Priority.high: 3,
  Priority.medium: 2,
  Priority.low: 1,
};

const _dayNames = ['', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday'];

class SchedulerEngine {
  List<GeneratedSchedule> generateSchedules({
    required List<Subject> subjects,
    required Map<String, List<TimeSlot>> availableSlots,
    required List<DateTime> blockedDates,
    required Constraints constraints,
  }) {
    return [
      _buildSchedule(
        type: ScheduleType.balanced,
        title: 'Balanced plan',
        description: 'Equal time across all subjects with moderate daily hours. Prioritizes subjects by proficiency gap and exam proximity.',
        hoursPerDay: constraints.dailyMinHours * 0.65,
        focusStrategy: 'Rotate subjects daily with revision every 3 days.',
        subjects: subjects,
        availableSlots: availableSlots,
        blockedDates: blockedDates,
        constraints: constraints,
        multiplier: 0.65,
      ),
      _buildSchedule(
        type: ScheduleType.aggressive,
        title: 'Aggressive plan',
        description: 'Maximum daily hours with heavy focus on weak subjects. Covers all topics before exam week.',
        hoursPerDay: constraints.dailyMinHours.toDouble(),
        focusStrategy: 'Double sessions on low-proficiency subjects.',
        subjects: subjects,
        availableSlots: availableSlots,
        blockedDates: blockedDates,
        constraints: constraints,
        multiplier: 1.0,
      ),
      _buildSchedule(
        type: ScheduleType.relaxed,
        title: 'Stress-free plan',
        description: 'Shorter daily sessions to prevent burnout. Focuses on high-priority subjects only.',
        hoursPerDay: constraints.dailyMinHours * 0.4,
        focusStrategy: 'One subject per day, no late evening sessions.',
        subjects: subjects,
        availableSlots: availableSlots,
        blockedDates: blockedDates,
        constraints: constraints,
        multiplier: 0.4,
      ),
    ];
  }

  GeneratedSchedule _buildSchedule({
    required ScheduleType type,
    required String title,
    required String description,
    required double hoursPerDay,
    required String focusStrategy,
    required List<Subject> subjects,
    required Map<String, List<TimeSlot>> availableSlots,
    required List<DateTime> blockedDates,
    required Constraints constraints,
    required double multiplier,
  }) {
    final blocks = <StudyBlock>[];
    final today = DateTime.now();

    final sortedSubjects = List<Subject>.from(subjects)
      ..sort((a, b) => (_priorityWeights[b.priority] ?? 0).compareTo(_priorityWeights[a.priority] ?? 0));

    int subjectIndex = 0;
    int revisionCounter = 0;

    for (int dayOffset = 0; dayOffset < 28; dayOffset++) {
      final date = today.add(Duration(days: dayOffset));
      final dayName = _dayNames[date.weekday];

      if (blockedDates.any((b) => b.year == date.year && b.month == date.month && b.day == date.day)) continue;
      if (subjects.any((s) => s.examDate != null && s.examDate!.year == date.year && s.examDate!.month == date.month && s.examDate!.day == date.day)) continue;

      final daySlots = availableSlots[dayName];
      if (daySlots == null || daySlots.isEmpty) continue;

      double dayHoursUsed = 0;
      final targetHours = constraints.dailyMinHours * multiplier;

      for (final slot in daySlots) {
        if (dayHoursUsed >= targetHours) break;
        if (slot.startTime.hour >= constraints.noStudyAfterHour) continue;

        int currentHour = slot.startTime.hour;
        int currentMinute = slot.startTime.minute;

        while (true) {
          final currentTotalMin = currentHour * 60 + currentMinute;
          final slotEndTotalMin = slot.endTime.hour * 60 + slot.endTime.minute;
          final remaining = slotEndTotalMin - currentTotalMin;

          if (remaining < 60) break;
          if (dayHoursUsed >= targetHours) break;
          if (currentHour >= constraints.noStudyAfterHour) break;

          final sessionMinutes = remaining >= constraints.maxContinuousMinutes
              ? constraints.maxContinuousMinutes
              : (remaining >= 60 ? 60 : remaining);

          final endTotalMin = currentTotalMin + sessionMinutes;
          final subject = sortedSubjects[subjectIndex % sortedSubjects.length];
          revisionCounter++;

          blocks.add(StudyBlock(
            id: _uuid.v4(),
            date: DateTime(date.year, date.month, date.day),
            startTime: TimeOfDay(hour: currentHour, minute: currentMinute),
            endTime: TimeOfDay(hour: endTotalMin ~/ 60, minute: endTotalMin % 60),
            subjectId: subject.id,
            subjectName: subject.name,
            type: revisionCounter % constraints.revisionFrequencyDays == 0 ? StudyType.revise : StudyType.learn,
          ));

          dayHoursUsed += sessionMinutes / 60.0;
          subjectIndex++;

          currentMinute = endTotalMin % 60 + constraints.minBreakMinutes;
          currentHour = endTotalMin ~/ 60;
          if (currentMinute >= 60) {
            currentHour++;
            currentMinute -= 60;
          }
        }
      }
    }

    return GeneratedSchedule(
      type: type,
      title: title,
      description: description,
      hoursPerDay: hoursPerDay,
      focusStrategy: focusStrategy,
      blocks: blocks,
    );
  }
}

// lib/providers/app_state.dart

import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:uuid/uuid.dart';
import '../models/models.dart';
import '../services/ai_service.dart';
import '../services/scheduler_engine.dart';

const _uuid = Uuid();

bool _sameDay(DateTime a, DateTime b) =>
    a.year == b.year && a.month == b.month && a.day == b.day;

class AppState extends ChangeNotifier {
  // --- Profile ---
  List<Subject> subjects = [];
  Map<String, List<TimeSlot>> availableSlots = {};
  List<DateTime> blockedDates = [];

  // --- Constraints ---
  Constraints constraints = Constraints();

  // --- AI Key ---
  String apiKey = '';

  // --- Generated Schedules ---
  List<GeneratedSchedule> generatedSchedules = [];
  ScheduleType selectedScheduleType = ScheduleType.balanced;
  bool isGenerating = false;
  String? generationError;

  // --- Active Schedule ---
  List<StudyBlock> activeBlocks = [];

  // --- Post-exam ---
  List<ExamScore> examScores = [];
  String? aiAnalysis;
  bool isAnalyzing = false;

  // --- Navigation ---
  int currentPhase = 0;

  final AiService _aiService = AiService();
  final SchedulerEngine _engine = SchedulerEngine();

  AppState() {
    _loadDefaults();
    _loadFromPrefs();
  }

  void _loadDefaults() {
    subjects = [
      Subject(
        id: _uuid.v4(),
        name: 'Mathematics',
        totalTopics: 12,
        proficiency: 2,
        priority: Priority.high,
      ),
      Subject(
        id: _uuid.v4(),
        name: 'Physics',
        totalTopics: 10,
        proficiency: 3,
        priority: Priority.medium,
      ),
      Subject(
        id: _uuid.v4(),
        name: 'Chemistry',
        totalTopics: 8,
        proficiency: 4,
        priority: Priority.low,
      ),
    ];

    availableSlots = {
      'Monday': [TimeSlot(day: 'Monday', startTime: const TimeOfDay(hour: 9, minute: 0), endTime: const TimeOfDay(hour: 13, minute: 0))],
      'Wednesday': [TimeSlot(day: 'Wednesday', startTime: const TimeOfDay(hour: 9, minute: 0), endTime: const TimeOfDay(hour: 13, minute: 0))],
      'Friday': [TimeSlot(day: 'Friday', startTime: const TimeOfDay(hour: 9, minute: 0), endTime: const TimeOfDay(hour: 13, minute: 0))],
      'Saturday': [TimeSlot(day: 'Saturday', startTime: const TimeOfDay(hour: 9, minute: 0), endTime: const TimeOfDay(hour: 15, minute: 0))],
    };
  }

  // ---- SUBJECTS ----
  void addSubject(String name) {
    subjects.add(Subject(id: _uuid.v4(), name: name, proficiency: 3, priority: Priority.medium));
    notifyListeners();
    _saveToPrefs();
  }

  void updateSubject(String id, Subject updated) {
    final idx = subjects.indexWhere((s) => s.id == id);
    if (idx >= 0) {
      subjects[idx] = updated;
      notifyListeners();
      _saveToPrefs();
    }
  }

  void removeSubject(String id) {
    subjects.removeWhere((s) => s.id == id);
    notifyListeners();
    _saveToPrefs();
  }

  // ---- SLOTS ----
  void addSlot(String day, TimeSlot slot) {
    availableSlots.putIfAbsent(day, () => []).add(slot);
    notifyListeners();
    _saveToPrefs();
  }

  void removeSlot(String day, int index) {
    availableSlots[day]?.removeAt(index);
    if (availableSlots[day]?.isEmpty ?? false) availableSlots.remove(day);
    notifyListeners();
    _saveToPrefs();
  }

  void updateSlot(String day, int index, TimeSlot slot) {
    availableSlots[day]?[index] = slot;
    notifyListeners();
    _saveToPrefs();
  }

  // ---- BLOCKED DATES ----
  void addBlockedDate(DateTime date) {
    final d = DateTime(date.year, date.month, date.day);
    if (!blockedDates.any((b) => _sameDay(b, d))) {
      blockedDates.add(d);
      notifyListeners();
      _saveToPrefs();
    }
  }

  void removeBlockedDate(DateTime date) {
    blockedDates.removeWhere((b) => _sameDay(b, date));
    notifyListeners();
    _saveToPrefs();
  }

  bool isDateBlocked(DateTime date) => blockedDates.any((b) => _sameDay(b, date));

  bool isExamDate(DateTime date) =>
      subjects.any((s) => s.examDate != null && _sameDay(s.examDate!, date));

  List<Subject> subjectsOnDate(DateTime date) =>
      subjects.where((s) => s.examDate != null && _sameDay(s.examDate!, date)).toList();

  // ---- CONSTRAINTS ----
  void updateConstraints(Constraints c) {
    constraints = c;
    notifyListeners();
    _saveToPrefs();
  }

  void setApiKey(String key) {
    apiKey = key;
    notifyListeners();
  }

  // ---- GENERATE SCHEDULES ----
  Future<void> generateSchedules() async {
    isGenerating = true;
    generationError = null;
    generatedSchedules = [];
    notifyListeners();

    try {
      final schedules = await _aiService.generateSchedules(
        subjects: subjects,
        availableSlots: availableSlots,
        blockedDates: blockedDates,
        constraints: constraints,
        apiKey: apiKey,
      );
      generatedSchedules = schedules;
      if (generatedSchedules.isNotEmpty) selectSchedule(ScheduleType.balanced);
    } catch (e) {
      generatedSchedules = _engine.generateSchedules(
        subjects: subjects,
        availableSlots: availableSlots,
        blockedDates: blockedDates,
        constraints: constraints,
      );
      if (generatedSchedules.isNotEmpty) selectSchedule(ScheduleType.balanced);
      generationError = 'Using local scheduler (AI unavailable)';
    }

    isGenerating = false;
    notifyListeners();
  }

  void selectSchedule(ScheduleType type) {
    selectedScheduleType = type;
    final schedule = generatedSchedules.firstWhere(
      (s) => s.type == type,
      orElse: () => generatedSchedules.first,
    );
    activeBlocks = List.from(schedule.blocks);
    notifyListeners();
    _saveToPrefs();
  }

  GeneratedSchedule? get selectedSchedule {
    if (generatedSchedules.isEmpty) return null;
    return generatedSchedules.firstWhere(
      (s) => s.type == selectedScheduleType,
      orElse: () => generatedSchedules.first,
    );
  }

  // ---- STUDY MODE ----
  List<StudyBlock> get todayBlocks {
    final now = DateTime.now();
    return activeBlocks.where((b) => _sameDay(b.date, now)).toList();
  }

  List<StudyBlock> blocksForDate(DateTime date) =>
      activeBlocks.where((b) => _sameDay(b.date, date)).toList();

  void toggleBlockComplete(String blockId) {
    final idx = activeBlocks.indexWhere((b) => b.id == blockId);
    if (idx >= 0) {
      activeBlocks[idx].completed = !activeBlocks[idx].completed;
      notifyListeners();
      _saveToPrefs();
    }
  }

  double get overallProgress {
    if (activeBlocks.isEmpty) return 0;
    return activeBlocks.where((b) => b.completed).length / activeBlocks.length;
  }

  // ---- POST-EXAM ----
  void addOrUpdateScore(ExamScore score) {
    final idx = examScores.indexWhere((s) => s.subjectId == score.subjectId);
    if (idx >= 0) {
      examScores[idx] = score;
    } else {
      examScores.add(score);
    }
    notifyListeners();
  }

  Future<void> analyzeAndReschedule() async {
    isAnalyzing = true;
    aiAnalysis = null;
    notifyListeners();

    try {
      final analysis = await _aiService.analyzeScores(subjects: subjects, scores: examScores);
      aiAnalysis = analysis['text'];
      final priorities = analysis['priorities'] as Map<String, String>?;
      if (priorities != null) {
        for (final s in subjects) {
          final newPri = priorities[s.name];
          if (newPri != null) {
            final pri = Priority.values.firstWhere(
              (e) => e.name.toLowerCase() == newPri.toLowerCase(),
              orElse: () => s.priority,
            );
            updateSubject(s.id, s.copyWith(priority: pri));
          }
        }
      }
    } catch (e) {
      for (final score in examScores) {
        final idx = subjects.indexWhere((s) => s.id == score.subjectId);
        if (idx >= 0) {
          updateSubject(subjects[idx].id, subjects[idx].copyWith(priority: score.suggestedPriority));
        }
      }
      aiAnalysis = 'Priorities have been auto-updated based on your scores. Subjects below 50% are now high priority.';
    }

    isAnalyzing = false;
    notifyListeners();
  }

  // ---- NAVIGATION ----
  void goToPhase(int phase) {
    currentPhase = phase;
    notifyListeners();
  }

  // ---- PERSISTENCE ----
  Future<void> _saveToPrefs() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      prefs.setString('subjects', jsonEncode(subjects.map((s) => s.toJson()).toList()));
      prefs.setString('constraints', jsonEncode(constraints.toJson()));
      prefs.setString('blockedDates', jsonEncode(blockedDates.map((d) => d.toIso8601String()).toList()));
      final slotsJson = availableSlots.map((k, v) => MapEntry(k, v.map((sl) => sl.toJson()).toList()));
      prefs.setString('slots', jsonEncode(slotsJson));
    } catch (_) {}
  }

  Future<void> _loadFromPrefs() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      final subjectsJson = prefs.getString('subjects');
      if (subjectsJson != null) {
        subjects = (jsonDecode(subjectsJson) as List).map((j) => Subject.fromJson(j)).toList();
      }
      final constraintsJson = prefs.getString('constraints');
      if (constraintsJson != null) {
        constraints = Constraints.fromJson(jsonDecode(constraintsJson));
      }
      final blockedJson = prefs.getString('blockedDates');
      if (blockedJson != null) {
        blockedDates = (jsonDecode(blockedJson) as List).map((d) => DateTime.parse(d)).toList();
      }
      final slotsJson = prefs.getString('slots');
      if (slotsJson != null) {
        final map = jsonDecode(slotsJson) as Map<String, dynamic>;
        availableSlots = map.map((k, v) =>
            MapEntry(k, (v as List).map((sl) => TimeSlot.fromJson(sl)).toList()));
      }
      notifyListeners();
    } catch (_) {}
  }
}

// lib/models/models.dart

import 'package:flutter/material.dart';

enum Priority { high, medium, low }

enum StudyType { learn, revise }

enum ScheduleType { balanced, aggressive, relaxed }

class Subject {
  String id;
  String name;
  int totalTopics;
  int proficiency; // 1-5
  Priority priority;
  DateTime? examDate;
  String? prerequisites;
  int completedTopics;

  Subject({
    required this.id,
    required this.name,
    this.totalTopics = 8,
    this.proficiency = 3,
    this.priority = Priority.medium,
    this.examDate,
    this.prerequisites,
    this.completedTopics = 0,
  });

  Subject copyWith({
    String? name,
    int? totalTopics,
    int? proficiency,
    Priority? priority,
    DateTime? examDate,
    String? prerequisites,
    int? completedTopics,
  }) {
    return Subject(
      id: id,
      name: name ?? this.name,
      totalTopics: totalTopics ?? this.totalTopics,
      proficiency: proficiency ?? this.proficiency,
      priority: priority ?? this.priority,
      examDate: examDate ?? this.examDate,
      prerequisites: prerequisites ?? this.prerequisites,
      completedTopics: completedTopics ?? this.completedTopics,
    );
  }

  static const _priorityColors = {
    Priority.high: Color(0xFFE24B4A),
    Priority.medium: Color(0xFFEF9F27),
    Priority.low: Color(0xFF1D9E75),
  };

  static const _priorityLabels = {
    Priority.high: 'High',
    Priority.medium: 'Medium',
    Priority.low: 'Low',
  };

  Color get priorityColor => _priorityColors[priority]!;
  String get priorityLabel => _priorityLabels[priority]!;
  double get progressPercent => completedTopics / totalTopics;

  Map<String, dynamic> toJson() => {
        'id': id,
        'name': name,
        'totalTopics': totalTopics,
        'proficiency': proficiency,
        'priority': priority.name,
        'examDate': examDate?.toIso8601String(),
        'prerequisites': prerequisites,
        'completedTopics': completedTopics,
      };

  factory Subject.fromJson(Map<String, dynamic> json) => Subject(
        id: json['id'],
        name: json['name'],
        totalTopics: json['totalTopics'] ?? 8,
        proficiency: json['proficiency'] ?? 3,
        priority: Priority.values.firstWhere(
          (e) => e.name == json['priority'],
          orElse: () => Priority.medium,
        ),
        examDate: json['examDate'] != null
            ? DateTime.parse(json['examDate'])
            : null,
        prerequisites: json['prerequisites'],
        completedTopics: json['completedTopics'] ?? 0,
      );
}

class TimeSlot {
  String day;
  TimeOfDay startTime;
  TimeOfDay endTime;

  TimeSlot({
    required this.day,
    required this.startTime,
    required this.endTime,
  });

  double get durationHours {
    final startMin = startTime.hour * 60 + startTime.minute;
    final endMin = endTime.hour * 60 + endTime.minute;
    return (endMin - startMin) / 60.0;
  }

  Map<String, dynamic> toJson() => {
        'day': day,
        'startHour': startTime.hour,
        'startMinute': startTime.minute,
        'endHour': endTime.hour,
        'endMinute': endTime.minute,
      };

  factory TimeSlot.fromJson(Map<String, dynamic> json) => TimeSlot(
        day: json['day'],
        startTime: TimeOfDay(hour: json['startHour'], minute: json['startMinute']),
        endTime: TimeOfDay(hour: json['endHour'], minute: json['endMinute']),
      );
}

class Constraints {
  int maxContinuousMinutes;
  int minBreakMinutes;
  int dailyMinHours;
  int noStudyAfterHour;
  int revisionFrequencyDays;
  List<String> customRules;

  Constraints({
    this.maxContinuousMinutes = 90,
    this.minBreakMinutes = 15,
    this.dailyMinHours = 2,
    this.noStudyAfterHour = 23,
    this.revisionFrequencyDays = 3,
    this.customRules = const [],
  });

  Map<String, dynamic> toJson() => {
        'maxContinuousMinutes': maxContinuousMinutes,
        'minBreakMinutes': minBreakMinutes,
        'dailyMinHours': dailyMinHours,
        'noStudyAfterHour': noStudyAfterHour,
        'revisionFrequencyDays': revisionFrequencyDays,
        'customRules': customRules,
      };

  factory Constraints.fromJson(Map<String, dynamic> json) => Constraints(
        maxContinuousMinutes: json['maxContinuousMinutes'] ?? 90,
        minBreakMinutes: json['minBreakMinutes'] ?? 15,
        dailyMinHours: json['dailyMinHours'] ?? 2,
        noStudyAfterHour: json['noStudyAfterHour'] ?? 23,
        revisionFrequencyDays: json['revisionFrequencyDays'] ?? 3,
        customRules: (json['customRules'] as List?)?.map((e) => e.toString()).toList() ?? [],
      );
}

class StudyBlock {
  String id;
  DateTime date;
  TimeOfDay startTime;
  TimeOfDay endTime;
  String subjectId;
  String subjectName;
  StudyType type;
  bool completed;
  String? topic;

  StudyBlock({
    required this.id,
    required this.date,
    required this.startTime,
    required this.endTime,
    required this.subjectId,
    required this.subjectName,
    required this.type,
    this.completed = false,
    this.topic,
  });

  double get durationHours {
    final startMin = startTime.hour * 60 + startTime.minute;
    final endMin = endTime.hour * 60 + endTime.minute;
    return (endMin - startMin) / 60.0;
  }

  String get timeLabel {
    String fmt(TimeOfDay t) {
      final h = t.hourOfPeriod == 0 ? 12 : t.hourOfPeriod;
      final m = t.minute.toString().padLeft(2, '0');
      final period = t.period == DayPeriod.am ? 'am' : 'pm';
      return '$h:$m$period';
    }
    return '${fmt(startTime)} – ${fmt(endTime)}';
  }

  Map<String, dynamic> toJson() => {
        'id': id,
        'date': date.toIso8601String(),
        'startHour': startTime.hour,
        'startMinute': startTime.minute,
        'endHour': endTime.hour,
        'endMinute': endTime.minute,
        'subjectId': subjectId,
        'subjectName': subjectName,
        'type': type.name,
        'completed': completed,
        'topic': topic,
      };

  factory StudyBlock.fromJson(Map<String, dynamic> json) => StudyBlock(
        id: json['id'],
        date: DateTime.parse(json['date']),
        startTime: TimeOfDay(hour: json['startHour'], minute: json['startMinute']),
        endTime: TimeOfDay(hour: json['endHour'], minute: json['endMinute']),
        subjectId: json['subjectId'],
        subjectName: json['subjectName'],
        type: StudyType.values.firstWhere(
          (e) => e.name == json['type'],
          orElse: () => StudyType.learn,
        ),
        completed: json['completed'] ?? false,
        topic: json['topic'],
      );
}

class GeneratedSchedule {
  ScheduleType type;
  String title;
  String description;
  double hoursPerDay;
  String focusStrategy;
  List<StudyBlock> blocks;
  String? aiInsight;

  GeneratedSchedule({
    required this.type,
    required this.title,
    required this.description,
    required this.hoursPerDay,
    required this.focusStrategy,
    required this.blocks,
    this.aiInsight,
  });

  int get totalDays => blocks.map((b) => b.date.day).toSet().length;
  int get totalBlocks => blocks.length;
  double get totalHours => blocks.fold(0, (sum, b) => sum + b.durationHours);

  static const _typeColors = {
    ScheduleType.balanced: Color(0xFF1D9E75),
    ScheduleType.aggressive: Color(0xFFE24B4A),
    ScheduleType.relaxed: Color(0xFF533483),
  };

  static const _typeLabels = {
    ScheduleType.balanced: 'Balanced',
    ScheduleType.aggressive: 'Aggressive',
    ScheduleType.relaxed: 'Stress-free',
  };

  Color get color => _typeColors[type]!;
  String get typeLabel => _typeLabels[type]!;
}

class ExamScore {
  String subjectId;
  String subjectName;
  double score;
  DateTime examDate;

  ExamScore({
    required this.subjectId,
    required this.subjectName,
    required this.score,
    required this.examDate,
  });

  String get performanceLabel {
    if (score < 50) return 'Needs focus';
    if (score < 75) return 'Extra revision';
    return 'Light revision';
  }

  Color get performanceColor {
    if (score < 50) return const Color(0xFFE24B4A);
    if (score < 75) return const Color(0xFFEF9F27);
    return const Color(0xFF1D9E75);
  }

  Priority get suggestedPriority {
    if (score < 50) return Priority.high;
    if (score < 75) return Priority.medium;
    return Priority.low;
  }
}

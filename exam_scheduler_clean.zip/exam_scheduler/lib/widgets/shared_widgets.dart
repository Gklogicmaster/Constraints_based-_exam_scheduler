// lib/widgets/shared_widgets.dart

import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import '../theme.dart';
import '../models/models.dart';

// ---- Section Title ----
class SectionTitle extends StatelessWidget {
  final String text;
  const SectionTitle(this.text, {super.key});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 12),
      child: Text(
        text.toUpperCase(),
        style: GoogleFonts.dmSans(
          fontSize: 11,
          fontWeight: FontWeight.w500,
          color: AppTheme.textMuted,
          letterSpacing: 0.8,
        ),
      ),
    );
  }
}

// ---- App Card ----
class AppCard extends StatelessWidget {
  final Widget child;
  final EdgeInsets? padding;
  const AppCard({super.key, required this.child, this.padding});

  @override
  Widget build(BuildContext context) {
    return Container(
      width: double.infinity,
      margin: const EdgeInsets.only(bottom: 12),
      padding: padding ?? const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: AppTheme.border, width: 0.5),
      ),
      child: child,
    );
  }
}

// ---- Priority Badge ----
class PriorityBadge extends StatelessWidget {
  final Priority priority;
  const PriorityBadge(this.priority, {super.key});

  static const _bg = {
    Priority.high: Color(0xFFFCEBEB),
    Priority.medium: Color(0xFFFAEEDA),
    Priority.low: Color(0xFFEAF3DE),
  };
  static const _fg = {
    Priority.high: Color(0xFFA32D2D),
    Priority.medium: Color(0xFF854F0B),
    Priority.low: Color(0xFF3B6D11),
  };
  static const _labels = {
    Priority.high: 'High',
    Priority.medium: 'Medium',
    Priority.low: 'Low',
  };

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
      decoration: BoxDecoration(
        color: _bg[priority],
        borderRadius: BorderRadius.circular(6),
      ),
      child: Text(
        _labels[priority]!,
        style: GoogleFonts.dmSans(fontSize: 11, fontWeight: FontWeight.w500, color: _fg[priority]),
      ),
    );
  }
}

// ---- Study Type Badge ----
class StudyTypeBadge extends StatelessWidget {
  final StudyType type;
  const StudyTypeBadge(this.type, {super.key});

  @override
  Widget build(BuildContext context) {
    final isLearn = type == StudyType.learn;
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 7, vertical: 2),
      decoration: BoxDecoration(
        color: isLearn ? const Color(0xFFE6F1FB) : const Color(0xFFFAEEDA),
        borderRadius: BorderRadius.circular(4),
      ),
      child: Text(
        isLearn ? 'Learn' : 'Revise',
        style: GoogleFonts.dmSans(
          fontSize: 10,
          fontWeight: FontWeight.w500,
          color: isLearn ? const Color(0xFF185FA5) : const Color(0xFF854F0B),
        ),
      ),
    );
  }
}

// ---- Subject Color Dot ----
class SubjectDot extends StatelessWidget {
  final int colorIndex;
  final double size;
  const SubjectDot({super.key, required this.colorIndex, this.size = 10});

  @override
  Widget build(BuildContext context) {
    return Container(
      width: size,
      height: size,
      decoration: BoxDecoration(
        color: AppTheme.subjectColors[colorIndex % AppTheme.subjectColors.length],
        borderRadius: BorderRadius.circular(size / 2),
      ),
    );
  }
}

// ---- Progress Bar ----
class AppProgressBar extends StatelessWidget {
  final double value; // 0.0 to 1.0
  final Color? color;
  final double height;
  const AppProgressBar({super.key, required this.value, this.color, this.height = 6});

  @override
  Widget build(BuildContext context) {
    return ClipRRect(
      borderRadius: BorderRadius.circular(height / 2),
      child: LinearProgressIndicator(
        value: value.clamp(0.0, 1.0),
        minHeight: height,
        backgroundColor: AppTheme.border,
        valueColor: AlwaysStoppedAnimation<Color>(color ?? AppTheme.primary),
      ),
    );
  }
}

// ---- Metric Card ----
class MetricCard extends StatelessWidget {
  final String value;
  final String label;
  final Color? color;
  const MetricCard({super.key, required this.value, required this.label, this.color});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: AppTheme.surface,
        borderRadius: BorderRadius.circular(10),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          Text(
            value,
            style: GoogleFonts.dmSans(
              fontSize: 24,
              fontWeight: FontWeight.w500,
              color: color ?? AppTheme.textPrimary,
            ),
          ),
          const SizedBox(height: 4),
          Text(label, style: GoogleFonts.dmSans(fontSize: 12, color: AppTheme.textSecondary)),
        ],
      ),
    );
  }
}

// ---- Empty State ----
class EmptyState extends StatelessWidget {
  final String icon;
  final String message;
  const EmptyState({super.key, required this.icon, required this.message});

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(32),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Text(icon, style: const TextStyle(fontSize: 40)),
            const SizedBox(height: 12),
            Text(
              message,
              textAlign: TextAlign.center,
              style: GoogleFonts.dmSans(fontSize: 14, color: AppTheme.textSecondary),
            ),
          ],
        ),
      ),
    );
  }
}

// ---- Phase Nav Bar ----
class PhaseNavBar extends StatelessWidget {
  final int currentPhase;
  final Function(int) onPhaseSelected;

  const PhaseNavBar({
    super.key,
    required this.currentPhase,
    required this.onPhaseSelected,
  });

  static const _phases = [
    {'icon': Icons.person_outline, 'label': 'Profile'},
    {'icon': Icons.tune, 'label': 'Constraints'},
    {'icon': Icons.calendar_month, 'label': 'Generate'},
    {'icon': Icons.edit_note, 'label': 'Study'},
    {'icon': Icons.bar_chart, 'label': 'Post-exam'},
  ];

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
        color: Colors.white,
        border: Border(top: BorderSide(color: AppTheme.border, width: 0.5)),
      ),
      child: Row(
        children: List.generate(_phases.length, (i) {
          final isActive = i == currentPhase;
          return Expanded(
            child: GestureDetector(
              onTap: () => onPhaseSelected(i),
              behavior: HitTestBehavior.opaque,
              child: Container(
                padding: const EdgeInsets.symmetric(vertical: 10),
                decoration: BoxDecoration(
                  border: Border(
                    top: BorderSide(
                      color: isActive ? AppTheme.primary : Colors.transparent,
                      width: 2,
                    ),
                  ),
                ),
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Icon(
                      _phases[i]['icon'] as IconData,
                      size: 20,
                      color: isActive ? AppTheme.primary : AppTheme.textMuted,
                    ),
                    const SizedBox(height: 3),
                    Text(
                      _phases[i]['label'] as String,
                      style: GoogleFonts.dmSans(
                        fontSize: 10,
                        color: isActive ? AppTheme.primary : AppTheme.textMuted,
                        fontWeight: isActive ? FontWeight.w500 : FontWeight.normal,
                      ),
                    ),
                  ],
                ),
              ),
            ),
          );
        }),
      ),
    );
  }
}

// lib/theme.dart

import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

class AppTheme {
  static const Color primary = Color(0xFFE94560);
  static const Color accent = Color(0xFF533483);
  static const Color surface = Color(0xFFF8F8F8);
  static const Color cardBg = Colors.white;

  static const Color success = Color(0xFF1D9E75);
  static const Color warning = Color(0xFFEF9F27);
  static const Color danger = Color(0xFFE24B4A);
  static const Color info = Color(0xFF185FA5);

  static const Color textPrimary = Color(0xFF1A1A1A);
  static const Color textSecondary = Color(0xFF6B6B6B);
  static const Color textMuted = Color(0xFF9E9E9E);
  static const Color border = Color(0xFFE0E0E0);

  // Subject colors
  static const List<Color> subjectColors = [
    Color(0xFF185FA5), // blue
    Color(0xFF1D9E75), // teal
    Color(0xFF533483), // purple
    Color(0xFFE24B4A), // red
    Color(0xFFEF9F27), // amber
    Color(0xFF0F6E56), // dark teal
  ];

  static const List<Color> subjectBgColors = [
    Color(0xFFE6F1FB),
    Color(0xFFE1F5EE),
    Color(0xFFEEEDFE),
    Color(0xFFFCEBEB),
    Color(0xFFFAEEDA),
    Color(0xFFD4EDE6),
  ];

  static ThemeData get light => ThemeData(
        useMaterial3: true,
        colorScheme: ColorScheme.fromSeed(
          seedColor: primary,
          surface: surface,
        ),
        textTheme: GoogleFonts.dmSansTextTheme(),
        scaffoldBackgroundColor: surface,
        appBarTheme: AppBarTheme(
          backgroundColor: Colors.white,
          elevation: 0,
          centerTitle: false,
          titleTextStyle: GoogleFonts.dmSans(
            fontSize: 18,
            fontWeight: FontWeight.w600,
            color: textPrimary,
          ),
          iconTheme: const IconThemeData(color: textPrimary),
        ),
        cardTheme: CardThemeData(
          color: cardBg,
          elevation: 0,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(12),
            side: const BorderSide(color: border, width: 0.5),
          ),
          margin: EdgeInsets.zero,
        ),
        elevatedButtonTheme: ElevatedButtonThemeData(
          style: ElevatedButton.styleFrom(
            backgroundColor: primary,
            foregroundColor: Colors.white,
            elevation: 0,
            padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 12),
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(10),
            ),
            textStyle: GoogleFonts.dmSans(
              fontSize: 14,
              fontWeight: FontWeight.w500,
            ),
          ),
        ),
        outlinedButtonTheme: OutlinedButtonThemeData(
          style: OutlinedButton.styleFrom(
            foregroundColor: textPrimary,
            side: const BorderSide(color: border),
            padding:
                const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(10),
            ),
            textStyle: GoogleFonts.dmSans(fontSize: 13),
          ),
        ),
        inputDecorationTheme: InputDecorationTheme(
          filled: true,
          fillColor: surface,
          border: OutlineInputBorder(
            borderRadius: BorderRadius.circular(8),
            borderSide: const BorderSide(color: border),
          ),
          enabledBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(8),
            borderSide: const BorderSide(color: border),
          ),
          focusedBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(8),
            borderSide: const BorderSide(color: primary, width: 1.5),
          ),
          contentPadding:
              const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
          labelStyle: GoogleFonts.dmSans(
              fontSize: 13, color: textSecondary),
          hintStyle: GoogleFonts.dmSans(
              fontSize: 13, color: textMuted),
        ),
        chipTheme: ChipThemeData(
          backgroundColor: surface,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(6),
            side: const BorderSide(color: border),
          ),
          labelStyle: GoogleFonts.dmSans(fontSize: 12),
          padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
        ),
        dividerTheme: const DividerThemeData(
          color: border,
          thickness: 0.5,
          space: 1,
        ),
        tabBarTheme: TabBarThemeData(
          labelColor: primary,
          unselectedLabelColor: textSecondary,
          indicatorColor: primary,
          labelStyle: GoogleFonts.dmSans(
              fontSize: 13, fontWeight: FontWeight.w500),
          unselectedLabelStyle: GoogleFonts.dmSans(fontSize: 13),
        ),
      );
}

// Shared UI constants
class AppConsts {
  static const phases = [
    {'label': '1 — Profile', 'icon': '📚'},
    {'label': '2 — Constraints', 'icon': '⚙️'},
    {'label': '3 — Generate', 'icon': '🗓️'},
    {'label': '4 — Study', 'icon': '✏️'},
    {'label': '5 — Post-exam', 'icon': '📊'},
  ];

  static const weekdays = [
    'Monday', 'Tuesday', 'Wednesday', 'Thursday',
    'Friday', 'Saturday', 'Sunday'
  ];
}

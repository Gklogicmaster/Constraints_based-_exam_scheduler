// lib/screens/phase4_study.dart

import 'dart:async';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:google_fonts/google_fonts.dart';
import '../providers/app_state.dart';
import '../models/models.dart';
import '../theme.dart';
import '../widgets/shared_widgets.dart';

class Phase4Study extends StatelessWidget {
  const Phase4Study({super.key});

  @override
  Widget build(BuildContext context) {
    final state = context.watch<AppState>();

    return SingleChildScrollView(
      padding: const EdgeInsets.all(16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Container(
                width: 40,
                height: 40,
                decoration: BoxDecoration(
                  color: AppTheme.surface,
                  borderRadius: BorderRadius.circular(20),
                  border: Border.all(color: AppTheme.border),
                ),
                child: const Center(
                    child: Text('✏️', style: TextStyle(fontSize: 18))),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text('Study mode',
                        style: GoogleFonts.dmSans(
                            fontSize: 16, fontWeight: FontWeight.w600)),
                    Text("Today's blocks and overall progress",
                        style: GoogleFonts.dmSans(
                            fontSize: 12,
                            color: AppTheme.textSecondary)),
                  ],
                ),
              ),
            ],
          ),
          const SizedBox(height: 16),

          // Overall progress
          AppCard(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    const SectionTitle('Overall progress'),
                    Text(
                      '${(state.overallProgress * 100).round()}%',
                      style: GoogleFonts.dmSans(
                          fontSize: 14,
                          fontWeight: FontWeight.w600,
                          color: AppTheme.primary),
                    ),
                  ],
                ),
                if (state.activeBlocks.isEmpty)
                  Padding(
                    padding: const EdgeInsets.only(top: 4, bottom: 4),
                    child: Text(
                      'No schedule selected yet. Go to Generate tab and pick a plan.',
                      style: GoogleFonts.dmSans(
                          fontSize: 12, color: AppTheme.textMuted),
                    ),
                  )
                else ...[
                  AppProgressBar(value: state.overallProgress),
                  const SizedBox(height: 8),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Text(
                        '${state.activeBlocks.where((b) => b.completed).length} of ${state.activeBlocks.length} blocks completed',
                        style: GoogleFonts.dmSans(
                            fontSize: 12, color: AppTheme.textSecondary),
                      ),
                      Text(
                        '${state.activeBlocks.length - state.activeBlocks.where((b) => b.completed).length} remaining',
                        style: GoogleFonts.dmSans(
                            fontSize: 12, color: AppTheme.textMuted),
                      ),
                    ],
                  ),
                ],
              ],
            ),
          ),

          // Pomodoro timer
          const _PomodoroTimer(),

          // Today's blocks
          AppCard(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const SectionTitle("Today's blocks"),
                if (state.todayBlocks.isEmpty)
                  const EmptyState(
                    icon: '☀️',
                    message:
                        'No sessions scheduled today. Rest or review past topics.',
                  )
                else
                  ...state.todayBlocks.map(
                    (b) => _StudyBlockTile(block: b),
                  ),
              ],
            ),
          ),

          // Subject progress
          AppCard(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const SectionTitle('Subject progress'),
                ...state.subjects.asMap().entries.map((e) {
                      final subject = e.value;
                      final subjectBlocks = state.activeBlocks
                          .where((b) => b.subjectId == subject.id);
                      final total = subjectBlocks.length;
                      final done = subjectBlocks.where((b) => b.completed).length;
                      final ratio = total == 0 ? 0.0 : done / total;
                      return Padding(
                        padding: const EdgeInsets.only(bottom: 12),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Row(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              children: [
                                Row(
                                  children: [
                                    SubjectDot(colorIndex: e.key),
                                    const SizedBox(width: 6),
                                    Text(subject.name,
                                        style: GoogleFonts.dmSans(fontSize: 13)),
                                  ],
                                ),
                                Row(
                                  children: [
                                    PriorityBadge(subject.priority),
                                    const SizedBox(width: 6),
                                    Text(
                                      '$done/$total blocks',
                                      style: GoogleFonts.dmSans(
                                          fontSize: 11,
                                          color: AppTheme.textSecondary),
                                    ),
                                  ],
                                ),
                              ],
                            ),
                            const SizedBox(height: 6),
                            AppProgressBar(
                              value: ratio,
                              color: AppTheme.subjectColors[
                                  e.key % AppTheme.subjectColors.length],
                            ),
                          ],
                        ),
                      );
                    }),
              ],
            ),
          ),

          SizedBox(
            width: double.infinity,
            child: ElevatedButton(
              onPressed: () =>
                  context.read<AppState>().goToPhase(4),
              child: const Text('Log exam results →'),
            ),
          ),
          const SizedBox(height: 16),
        ],
      ),
    );
  }
}

class _StudyBlockTile extends StatelessWidget {
  final StudyBlock block;
  const _StudyBlockTile({required this.block});

  @override
  Widget build(BuildContext context) {
    final state = context.read<AppState>();
    final subjectIdx = state.subjects.indexWhere((s) => s.id == block.subjectId);
    final color = AppTheme.subjectColors[
        subjectIdx >= 0 ? subjectIdx % AppTheme.subjectColors.length : 0];

    return Container(
      margin: const EdgeInsets.only(bottom: 8),
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: block.completed ? AppTheme.surface : Colors.white,
        borderRadius: BorderRadius.circular(10),
        border: Border.all(
          color: block.completed ? AppTheme.border : color.withValues(alpha: 0.3),
        ),
      ),
      child: Row(
        children: [
          Container(
            width: 4,
            height: 44,
            decoration: BoxDecoration(
              color: block.completed ? AppTheme.border : color,
              borderRadius: BorderRadius.circular(2),
            ),
          ),
          const SizedBox(width: 10),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  block.subjectName,
                  style: GoogleFonts.dmSans(
                    fontSize: 14,
                    fontWeight: FontWeight.w500,
                    decoration: block.completed
                        ? TextDecoration.lineThrough
                        : null,
                    color: block.completed
                        ? AppTheme.textMuted
                        : AppTheme.textPrimary,
                  ),
                ),
                const SizedBox(height: 2),
                Row(
                  children: [
                    Text(
                      block.timeLabel,
                      style: GoogleFonts.dmSans(
                          fontSize: 11, color: AppTheme.textSecondary),
                    ),
                    const SizedBox(width: 8),
                    StudyTypeBadge(block.type),
                  ],
                ),
              ],
            ),
          ),
          GestureDetector(
            onTap: () => context
                .read<AppState>()
                .toggleBlockComplete(block.id),
            child: Container(
              width: 28,
              height: 28,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                color: block.completed ? AppTheme.success : Colors.white,
                border: Border.all(
                  color: block.completed
                      ? AppTheme.success
                      : AppTheme.border,
                  width: 1.5,
                ),
              ),
              child: block.completed
                  ? const Icon(Icons.check, size: 16, color: Colors.white)
                  : null,
            ),
          ),
        ],
      ),
    );
  }
}

// ---- Pomodoro Timer ----
class _PomodoroTimer extends StatefulWidget {
  const _PomodoroTimer();

  @override
  State<_PomodoroTimer> createState() => _PomodoroTimerState();
}

class _PomodoroTimerState extends State<_PomodoroTimer> {
  static const _workDuration = 1 * 60;
  static const _breakDuration = 1 * 60;

  int _secondsLeft = _workDuration;
  bool _isRunning = false;
  bool _isBreak = false;
  Timer? _timer;
  int _cycles = 0;

  void _toggle() {
    setState(() {
      _isRunning = !_isRunning;
      if (_isRunning) {
        _timer = Timer.periodic(const Duration(seconds: 1), (_) {
          setState(() {
            if (_secondsLeft > 0) {
              _secondsLeft--;
            } else {
              if (!_isBreak) {
                // Focus session just ended — mark next incomplete block as complete
                final state = context.read<AppState>();
                final next = state.activeBlocks.firstWhere(
                  (b) => !b.completed,
                  orElse: () => state.activeBlocks.isNotEmpty
                      ? state.activeBlocks.first
                      : StudyBlock(
                          id: '',
                          date: DateTime.now(),
                          startTime: const TimeOfDay(hour: 0, minute: 0),
                          endTime: const TimeOfDay(hour: 0, minute: 0),
                          subjectId: '',
                          subjectName: '',
                          type: StudyType.learn,
                        ),
                );
                if (next.id.isNotEmpty && !next.completed) {
                  state.toggleBlockComplete(next.id);
                }
                _cycles++;
              }
              _isBreak = !_isBreak;
              _secondsLeft = _isBreak ? _breakDuration : _workDuration;
              _isRunning = false;
              _timer?.cancel();
            }
          });
        });
      } else {
        _timer?.cancel();
      }
    });
  }

  void _reset() {
    _timer?.cancel();
    setState(() {
      _isRunning = false;
      _isBreak = false;
      _secondsLeft = _workDuration;
    });
  }

  String get _timeString {
    final m = (_secondsLeft ~/ 60).toString().padLeft(2, '0');
    final s = (_secondsLeft % 60).toString().padLeft(2, '0');
    return '$m:$s';
  }

  double get _progress =>
      1 - (_secondsLeft / (_isBreak ? _breakDuration : _workDuration));

  @override
  void dispose() {
    _timer?.cancel();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return AppCard(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const SectionTitle('Pomodoro timer'),
          Row(
            children: [
              SizedBox(
                width: 80,
                height: 80,
                child: Stack(
                  alignment: Alignment.center,
                  children: [
                    SizedBox(
                      width: 80,
                      height: 80,
                      child: CircularProgressIndicator(
                        value: _progress,
                        strokeWidth: 6,
                        backgroundColor: AppTheme.border,
                        valueColor: AlwaysStoppedAnimation<Color>(
                          _isBreak ? AppTheme.success : AppTheme.primary,
                        ),
                      ),
                    ),
                    Text(
                      _timeString,
                      style: GoogleFonts.dmSans(
                        fontSize: 18,
                        fontWeight: FontWeight.w600,
                        color: _isBreak
                            ? AppTheme.success
                            : AppTheme.primary,
                      ),
                    ),
                  ],
                ),
              ),
              const SizedBox(width: 16),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      _isBreak ? 'Break time' : 'Focus session',
                      style: GoogleFonts.dmSans(
                          fontSize: 14, fontWeight: FontWeight.w500),
                    ),
                    Text(
                      'Cycle $_cycles completed',
                      style: GoogleFonts.dmSans(
                          fontSize: 12, color: AppTheme.textSecondary),
                    ),
                    const SizedBox(height: 10),
                    Row(
                      children: [
                        GestureDetector(
                          onTap: _toggle,
                          child: Container(
                            padding: const EdgeInsets.symmetric(
                                horizontal: 14, vertical: 7),
                            decoration: BoxDecoration(
                              color: _isBreak
                                  ? AppTheme.success
                                  : AppTheme.primary,
                              borderRadius: BorderRadius.circular(8),
                            ),
                            child: Text(
                              _isRunning ? 'Pause' : 'Start',
                              style: GoogleFonts.dmSans(
                                  fontSize: 13,
                                  color: Colors.white,
                                  fontWeight: FontWeight.w500),
                            ),
                          ),
                        ),
                        const SizedBox(width: 8),
                        GestureDetector(
                          onTap: _reset,
                          child: Container(
                            padding: const EdgeInsets.symmetric(
                                horizontal: 14, vertical: 7),
                            decoration: BoxDecoration(
                              border: Border.all(color: AppTheme.border),
                              borderRadius: BorderRadius.circular(8),
                            ),
                            child: Text(
                              'Reset',
                              style: GoogleFonts.dmSans(
                                  fontSize: 13,
                                  color: AppTheme.textSecondary),
                            ),
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }
}

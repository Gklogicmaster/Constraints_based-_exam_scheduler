// lib/screens/phase3_generate.dart

import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:table_calendar/table_calendar.dart';
import '../providers/app_state.dart';
import '../models/models.dart';
import '../theme.dart';
import '../widgets/shared_widgets.dart';

class Phase3Generate extends StatefulWidget {
  const Phase3Generate({super.key});

  @override
  State<Phase3Generate> createState() => _Phase3GenerateState();
}

class _Phase3GenerateState extends State<Phase3Generate> {
  DateTime _focusedDay = DateTime.now();
  DateTime? _selectedDay;
  bool _showTimetable = false;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) {
      final state = context.read<AppState>();
      if (state.generatedSchedules.isEmpty) {
        state.generateSchedules();
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    final state = context.watch<AppState>();

    return SingleChildScrollView(
      padding: const EdgeInsets.all(16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Container(
                width: 40,
                height: 40,
                decoration: BoxDecoration(
                  color: AppTheme.surface,
                  borderRadius: BorderRadius.circular(20),
                  border: Border.all(color: AppTheme.border),
                ),
                child: const Center(
                    child: Text('🗓️', style: TextStyle(fontSize: 18))),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text('Generated schedules',
                        style: GoogleFonts.dmSans(
                            fontSize: 16, fontWeight: FontWeight.w600)),
                    Text(
                        'Three optimized plans — pick the one that fits you',
                        style: GoogleFonts.dmSans(
                            fontSize: 12,
                            color: AppTheme.textSecondary)),
                  ],
                ),
              ),
            ],
          ),
          const SizedBox(height: 16),

          // Generate button
          if (!state.isGenerating)
            Padding(
              padding: const EdgeInsets.only(bottom: 12),
              child: OutlinedButton.icon(
                onPressed: () => state.generateSchedules(),
                icon: const Icon(Icons.refresh, size: 16),
                label: const Text('Regenerate'),
              ),
            ),

          if (state.isGenerating)
            AppCard(
              child: Column(
                children: [
                  const LinearProgressIndicator(
                      backgroundColor: AppTheme.border,
                      color: AppTheme.primary),
                  const SizedBox(height: 12),
                  Text('AI is generating your schedules...',
                      style: GoogleFonts.dmSans(
                          fontSize: 14,
                          color: AppTheme.textSecondary)),
                ],
              ),
            ),

          if (state.generationError != null)
            Padding(
              padding: const EdgeInsets.only(bottom: 8),
              child: Container(
                padding: const EdgeInsets.all(10),
                decoration: BoxDecoration(
                  color: const Color(0xFFFAEEDA),
                  borderRadius: BorderRadius.circular(8),
                ),
                child: Row(
                  children: [
                    const Icon(Icons.info_outline,
                        size: 16, color: Color(0xFF854F0B)),
                    const SizedBox(width: 8),
                    Expanded(
                      child: Text(state.generationError!,
                          style: GoogleFonts.dmSans(
                              fontSize: 12,
                              color: const Color(0xFF854F0B))),
                    ),
                  ],
                ),
              ),
            ),

          if (state.generatedSchedules.isNotEmpty) ...[
            // Schedule option cards
            ...state.generatedSchedules.map(
              (s) => _ScheduleOptionCard(
                schedule: s,
                isSelected: s.type == state.selectedScheduleType,
                onSelect: () => state.selectSchedule(s.type),
              ),
            ),
            const SizedBox(height: 4),

            // Stats row
            if (state.selectedSchedule != null) ...[
              Row(
                children: [
                  Expanded(
                    child: MetricCard(
                      value: '${state.selectedSchedule!.totalDays}',
                      label: 'study days',
                    ),
                  ),
                  const SizedBox(width: 8),
                  Expanded(
                    child: MetricCard(
                      value: '${state.selectedSchedule!.totalBlocks}',
                      label: 'blocks',
                    ),
                  ),
                  const SizedBox(width: 8),
                  Expanded(
                    child: MetricCard(
                      value:
                          '${state.selectedSchedule!.totalHours.round()}h',
                      label: 'total',
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 16),

              // Timetable toggle
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Text('View as timetable',
                      style: GoogleFonts.dmSans(
                          fontSize: 13, fontWeight: FontWeight.w500)),
                  Switch(
                    value: _showTimetable,
                    activeColor: AppTheme.primary,
                    onChanged: (v) => setState(() => _showTimetable = v),
                  ),
                ],
              ),

              if (_showTimetable)
                _TimetableView(schedule: state.selectedSchedule!, subjects: state.subjects),

              if (!_showTimetable)
              // Calendar
              AppCard(
                padding: const EdgeInsets.all(8),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Padding(
                      padding: const EdgeInsets.fromLTRB(8, 8, 8, 4),
                      child: Text('Schedule calendar',
                          style: GoogleFonts.dmSans(
                              fontSize: 13,
                              fontWeight: FontWeight.w500)),
                    ),
                    TableCalendar(
                      firstDay: DateTime.now()
                          .subtract(const Duration(days: 1)),
                      lastDay: DateTime.now()
                          .add(const Duration(days: 90)),
                      focusedDay: _focusedDay,
                      selectedDayPredicate: (day) =>
                          isSameDay(_selectedDay, day),
                      onDaySelected: (selected, focused) {
                        setState(() {
                          _selectedDay = selected;
                          _focusedDay = focused;
                        });
                      },
                      calendarBuilders: CalendarBuilders(
                        defaultBuilder: (ctx, day, focusedDay) =>
                            _dayBuilder(ctx, day, state),
                        todayBuilder: (ctx, day, focusedDay) =>
                            _dayBuilder(ctx, day, state, isToday: true),
                        selectedBuilder: (ctx, day, focusedDay) =>
                            _dayBuilder(ctx, day, state,
                                isSelected: true),
                      ),
                      calendarStyle: CalendarStyle(
                        outsideDaysVisible: false,
                        defaultTextStyle: GoogleFonts.dmSans(
                            fontSize: 12),
                        weekendTextStyle: GoogleFonts.dmSans(
                            fontSize: 12,
                            color: AppTheme.textSecondary),

                      ),
                      headerStyle: HeaderStyle(
                        formatButtonVisible: false,
                        titleCentered: true,
                        titleTextStyle: GoogleFonts.dmSans(
                            fontSize: 14, fontWeight: FontWeight.w500),
                        leftChevronIcon: const Icon(
                            Icons.chevron_left,
                            size: 20),
                        rightChevronIcon: const Icon(
                            Icons.chevron_right,
                            size: 20),
                      ),
                      eventLoader: (day) {
                        return state.selectedSchedule!.blocks
                            .where((b) => isSameDay(b.date, day))
                            .toList();
                      },
                    ),
                    if (_selectedDay != null) ...[
                      const Divider(),
                      _DayDetailPanel(
                          day: _selectedDay!, state: state),
                    ],
                  ],
                ),
              ),
            ],
          ],

          const SizedBox(height: 8),
          Row(
            children: [
              OutlinedButton(
                onPressed: () =>
                    context.read<AppState>().goToPhase(1),
                child: const Text('← Back'),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: ElevatedButton(
                  onPressed: state.generatedSchedules.isNotEmpty
                      ? () => context.read<AppState>().goToPhase(3)
                      : null,
                  child: const Text('Start studying →'),
                ),
              ),
            ],
          ),
          const SizedBox(height: 16),
        ],
      ),
    );
  }

  Widget _dayBuilder(
    BuildContext context,
    DateTime day,
    AppState state, {
    bool isToday = false,
    bool isSelected = false,
  }) {
    final isBlocked = state.isDateBlocked(day);
    final isExam = state.isExamDate(day);
    final hasBlocks = state.selectedSchedule != null &&
        state.selectedSchedule!.blocks.any((b) => isSameDay(b.date, day));

    Color? bg;
    Color textColor = AppTheme.textPrimary;

    if (isSelected) {
      bg = AppTheme.primary;
      textColor = Colors.white;
    } else if (isBlocked) {
      bg = const Color(0xFFFCEBEB);
    } else if (isExam) {
      bg = const Color(0xFFFAEEDA);
    } else if (isToday) {
      bg = const Color(0xFFEEEDFE);
    }

    return Container(
      margin: const EdgeInsets.all(2),
      decoration: BoxDecoration(
        color: bg,
        borderRadius: BorderRadius.circular(6),
        border: isToday && !isSelected
            ? Border.all(color: AppTheme.accent, width: 1)
            : null,
      ),
      child: Stack(
        alignment: Alignment.center,
        children: [
          Center(
            child: Text(
              '${day.day}',
              style: GoogleFonts.dmSans(
                fontSize: 12,
                color: textColor,
                fontWeight: isToday ? FontWeight.w600 : FontWeight.normal,
              ),
            ),
          ),
          if (hasBlocks && !isSelected)
            Positioned(
              bottom: 3,
              child: Container(
                width: 5,
                height: 5,
                decoration: BoxDecoration(
                  color: AppTheme.primary,
                  borderRadius: BorderRadius.circular(3),
                ),
              ),
            ),
        ],
      ),
    );
  }
}

class _ScheduleOptionCard extends StatelessWidget {
  final GeneratedSchedule schedule;
  final bool isSelected;
  final VoidCallback onSelect;

  const _ScheduleOptionCard({
    required this.schedule,
    required this.isSelected,
    required this.onSelect,
  });

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onSelect,
      child: Container(
        margin: const EdgeInsets.only(bottom: 10),
        padding: const EdgeInsets.all(14),
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(12),
          border: Border.all(
            color: isSelected ? AppTheme.primary : AppTheme.border,
            width: isSelected ? 2 : 0.5,
          ),
        ),
        child: Row(
          children: [
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      Container(
                        padding: const EdgeInsets.symmetric(
                            horizontal: 8, vertical: 3),
                        decoration: BoxDecoration(
                          color: schedule.color.withValues(alpha: 0.12),
                          borderRadius: BorderRadius.circular(5),
                        ),
                        child: Text(
                          schedule.typeLabel,
                          style: GoogleFonts.dmSans(
                            fontSize: 11,
                            fontWeight: FontWeight.w500,
                            color: schedule.color,
                          ),
                        ),
                      ),
                      const SizedBox(width: 8),
                      Text(
                        '${schedule.hoursPerDay.toStringAsFixed(1)}h/day avg',
                        style: GoogleFonts.dmSans(
                            fontSize: 12,
                            color: AppTheme.textSecondary),
                      ),
                    ],
                  ),
                  const SizedBox(height: 6),
                  Text(
                    schedule.title,
                    style: GoogleFonts.dmSans(
                        fontSize: 14, fontWeight: FontWeight.w500),
                  ),
                  const SizedBox(height: 3),
                  Text(
                    schedule.description,
                    style: GoogleFonts.dmSans(
                        fontSize: 12, color: AppTheme.textSecondary),
                    maxLines: 2,
                    overflow: TextOverflow.ellipsis,
                  ),
                ],
              ),
            ),
            const SizedBox(width: 12),
            Container(
              width: 24,
              height: 24,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                border: Border.all(
                  color: isSelected ? AppTheme.primary : AppTheme.border,
                  width: isSelected ? 2 : 1,
                ),
                color: isSelected ? AppTheme.primary : Colors.transparent,
              ),
              child: isSelected
                  ? const Icon(Icons.check,
                      size: 14, color: Colors.white)
                  : null,
            ),
          ],
        ),
      ),
    );
  }
}

class _DayDetailPanel extends StatelessWidget {
  final DateTime day;
  final AppState state;
  const _DayDetailPanel({required this.day, required this.state});

  @override
  Widget build(BuildContext context) {
    final blocks = state.selectedSchedule!.blocks
        .where((b) => isSameDay(b.date, day))
        .toList();
    final isBlocked = state.isDateBlocked(day);
    final examSubjects = state.subjectsOnDate(day);

    return Padding(
      padding: const EdgeInsets.fromLTRB(8, 8, 8, 4),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            '${day.day}/${day.month}/${day.year}',
            style: GoogleFonts.dmSans(
                fontSize: 13, fontWeight: FontWeight.w500),
          ),
          const SizedBox(height: 8),
          if (isBlocked)
            _InfoChip(
                label: 'Blocked day — no study',
                color: const Color(0xFFE24B4A))
          else if (examSubjects.isNotEmpty)
            ...examSubjects.map((s) => _InfoChip(
                label: '📝 ${s.name} exam',
                color: const Color(0xFFEF9F27)))
          else if (blocks.isEmpty)
            Text('No sessions scheduled',
                style: GoogleFonts.dmSans(
                    fontSize: 12, color: AppTheme.textMuted))
          else
            ...blocks.map((b) => Padding(
                  padding: const EdgeInsets.only(bottom: 6),
                  child: Row(
                    children: [
                      Container(
                        width: 4,
                        height: 36,
                        decoration: BoxDecoration(
                          color: AppTheme.subjectColors[
                              state.subjects.indexWhere(
                                      (s) => s.id == b.subjectId) %
                                  AppTheme.subjectColors.length],
                          borderRadius: BorderRadius.circular(2),
                        ),
                      ),
                      const SizedBox(width: 8),
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(b.subjectName,
                                style: GoogleFonts.dmSans(
                                    fontSize: 13,
                                    fontWeight: FontWeight.w500)),
                            Text(b.timeLabel,
                                style: GoogleFonts.dmSans(
                                    fontSize: 11,
                                    color: AppTheme.textSecondary)),
                          ],
                        ),
                      ),
                      StudyTypeBadge(b.type),
                    ],
                  ),
                )),
        ],
      ),
    );
  }
}

class _TimetableView extends StatelessWidget {
  final GeneratedSchedule schedule;
  final List<Subject> subjects;
  const _TimetableView({required this.schedule, required this.subjects});

  @override
  Widget build(BuildContext context) {
    // Group blocks by date, sorted
    final Map<DateTime, List<StudyBlock>> byDay = {};
    for (final b in schedule.blocks) {
      final key = DateTime(b.date.year, b.date.month, b.date.day);
      byDay.putIfAbsent(key, () => []).add(b);
    }
    final sortedDays = byDay.keys.toList()..sort();

    if (sortedDays.isEmpty) {
      return AppCard(
        child: const EmptyState(icon: '📅', message: 'No blocks generated yet.'),
      );
    }

    return AppCard(
      padding: const EdgeInsets.all(12),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text('Full timetable',
              style: GoogleFonts.dmSans(
                  fontSize: 13, fontWeight: FontWeight.w500)),
          const SizedBox(height: 12),
          ...sortedDays.map((day) {
            final blocks = byDay[day]!..sort((a, b) =>
                (a.startTime.hour * 60 + a.startTime.minute)
                    .compareTo(b.startTime.hour * 60 + b.startTime.minute));
            final weekday = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'][day.weekday - 1];
            return Padding(
              padding: const EdgeInsets.only(bottom: 12),
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  // Day label
                  SizedBox(
                    width: 52,
                    child: Column(
                      children: [
                        Text(weekday,
                            style: GoogleFonts.dmSans(
                                fontSize: 11, color: AppTheme.textMuted)),
                        Text('${day.day}/${day.month}',
                            style: GoogleFonts.dmSans(
                                fontSize: 13,
                                fontWeight: FontWeight.w600,
                                color: AppTheme.textPrimary)),
                      ],
                    ),
                  ),
                  const SizedBox(width: 8),
                  // Blocks
                  Expanded(
                    child: Column(
                      children: blocks.map((b) {
                        final subjectIdx = subjects.indexWhere((s) => s.id == b.subjectId);
                        final color = AppTheme.subjectColors[
                            subjectIdx >= 0 ? subjectIdx % AppTheme.subjectColors.length : 0];
                        final bg = AppTheme.subjectBgColors[
                            subjectIdx >= 0 ? subjectIdx % AppTheme.subjectBgColors.length : 0];
                        return Container(
                          margin: const EdgeInsets.only(bottom: 4),
                          padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 7),
                          decoration: BoxDecoration(
                            color: bg,
                            borderRadius: BorderRadius.circular(8),
                            border: Border.all(color: color.withValues(alpha: 0.3)),
                          ),
                          child: Row(
                            children: [
                              Container(
                                width: 3,
                                height: 30,
                                decoration: BoxDecoration(
                                  color: color,
                                  borderRadius: BorderRadius.circular(2),
                                ),
                              ),
                              const SizedBox(width: 8),
                              Expanded(
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Text(b.subjectName,
                                        style: GoogleFonts.dmSans(
                                            fontSize: 12,
                                            fontWeight: FontWeight.w500,
                                            color: color)),
                                    Text(b.timeLabel,
                                        style: GoogleFonts.dmSans(
                                            fontSize: 11,
                                            color: AppTheme.textSecondary)),
                                  ],
                                ),
                              ),
                              StudyTypeBadge(b.type),
                            ],
                          ),
                        );
                      }).toList(),
                    ),
                  ),
                ],
              ),
            );
          }),
        ],
      ),
    );
  }
}

class _InfoChip extends StatelessWidget {
  final String label;
  final Color color;
  const _InfoChip({required this.label, required this.color});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
      decoration: BoxDecoration(
        color: color.withValues(alpha: 0.1),
        borderRadius: BorderRadius.circular(6),
      ),
      child: Text(label,
          style: GoogleFonts.dmSans(fontSize: 12, color: color)),
    );
  }
}

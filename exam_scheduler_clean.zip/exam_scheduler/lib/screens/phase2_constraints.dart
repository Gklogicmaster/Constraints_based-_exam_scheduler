// lib/screens/phase2_constraints.dart

import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:google_fonts/google_fonts.dart';
import '../providers/app_state.dart';
import '../models/models.dart';
import '../theme.dart';
import '../widgets/shared_widgets.dart';

class Phase2Constraints extends StatefulWidget {
  const Phase2Constraints({super.key});

  @override
  State<Phase2Constraints> createState() => _Phase2ConstraintsState();
}

class _Phase2ConstraintsState extends State<Phase2Constraints> {
  late Constraints _local;

  @override
  void initState() {
    super.initState();
    _local = context.read<AppState>().constraints;
  }

  void _save() {
    context.read<AppState>().updateConstraints(_local);
  }

  @override
  Widget build(BuildContext context) {
    return SingleChildScrollView(
      padding: const EdgeInsets.all(16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Container(
                width: 40,
                height: 40,
                decoration: BoxDecoration(
                  color: AppTheme.surface,
                  borderRadius: BorderRadius.circular(20),
                  border: Border.all(color: AppTheme.border),
                ),
                child: const Center(
                    child: Text('⚙️', style: TextStyle(fontSize: 18))),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text('Study constraints',
                        style: GoogleFonts.dmSans(
                            fontSize: 16, fontWeight: FontWeight.w600)),
                    Text('Set your limits and personal study rules',
                        style: GoogleFonts.dmSans(
                            fontSize: 12,
                            color: AppTheme.textSecondary)),
                  ],
                ),
              ),
            ],
          ),
          const SizedBox(height: 16),
          AppCard(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const SectionTitle('Time limits'),
                _SliderRow(
                  label: 'Max continuous study',
                  value: _local.maxContinuousMinutes.toDouble(),
                  min: 30,
                  max: 180,
                  divisions: 15,
                  unit: 'min',
                  onChanged: (v) => setState(() {
                    _local.maxContinuousMinutes = v.round();
                    _save();
                  }),
                ),
                _SliderRow(
                  label: 'Break between sessions',
                  value: _local.minBreakMinutes.toDouble(),
                  min: 5,
                  max: 60,
                  divisions: 11,
                  unit: 'min',
                  onChanged: (v) => setState(() {
                    _local.minBreakMinutes = v.round();
                    _save();
                  }),
                ),
                _SliderRow(
                  label: 'Daily min hours',
                  value: _local.dailyMinHours.toDouble(),
                  min: 1,
                  max: 8,
                  divisions: 7,
                  unit: 'hrs',
                  onChanged: (v) => setState(() {
                    _local.dailyMinHours = v.round();
                    _save();
                  }),
                ),
              ],
            ),
          ),
          AppCard(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const SectionTitle('Study rules'),
                _StepperRow(
                  label: 'No study after',
                  value: _local.noStudyAfterHour,
                  min: 18,
                  max: 24,
                  display: (v) {
                    final h = v > 12 ? v - 12 : v;
                    final period = v >= 12 ? 'pm' : 'am';
                    return '$h:00 $period';
                  },
                  onChanged: (v) => setState(() {
                    _local.noStudyAfterHour = v;
                    _save();
                  }),
                ),
                const Divider(),
                _StepperRow(
                  label: 'Revision every (days)',
                  value: _local.revisionFrequencyDays,
                  min: 1,
                  max: 14,
                  display: (v) => v == 1 ? 'Every day' : 'Every $v days',
                  onChanged: (v) => setState(() {
                    _local.revisionFrequencyDays = v;
                    _save();
                  }),
                ),
                const Divider(),
                const SizedBox(height: 6),
                Text('My custom rules',
                    style: GoogleFonts.dmSans(
                        fontSize: 12,
                        fontWeight: FontWeight.w500,
                        color: AppTheme.textSecondary)),
                const SizedBox(height: 4),
                Text(
                  'Add any personal rule (e.g. "No studying on Sundays", "Start with hardest subject")',
                  style: GoogleFonts.dmSans(fontSize: 11, color: AppTheme.textMuted),
                ),
                const SizedBox(height: 10),
                _CustomRulesInput(
                  rules: _local.customRules,
                  onAdd: (rule) => setState(() {
                    _local.customRules = [..._local.customRules, rule];
                    _save();
                  }),
                  onRemove: (i) => setState(() {
                    final updated = List<String>.from(_local.customRules);
                    updated.removeAt(i);
                    _local.customRules = updated;
                    _save();
                  }),
                ),
              ],
            ),
          ),
          AppCard(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const SectionTitle('Topic prerequisites'),
                Text(
                  'Which subjects depend on others? (e.g., Physics depends on Mathematics)',
                  style: GoogleFonts.dmSans(
                      fontSize: 12, color: AppTheme.textSecondary),
                ),
                const SizedBox(height: 12),
                ...context.watch<AppState>().subjects.map(
                      (s) => _PrereqRow(subject: s),
                    ),
              ],
            ),
          ),
          const SizedBox(height: 8),
          Row(
            children: [
              OutlinedButton(
                onPressed: () =>
                    context.read<AppState>().goToPhase(0),
                child: const Text('← Back'),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: ElevatedButton(
                  onPressed: () =>
                      context.read<AppState>().goToPhase(2),
                  child: const Text('Generate schedules →'),
                ),
              ),
            ],
          ),
          const SizedBox(height: 16),
        ],
      ),
    );
  }
}

class _SliderRow extends StatelessWidget {
  final String label;
  final double value;
  final double min;
  final double max;
  final int divisions;
  final String unit;
  final Function(double) onChanged;

  const _SliderRow({
    required this.label,
    required this.value,
    required this.min,
    required this.max,
    required this.divisions,
    required this.unit,
    required this.onChanged,
  });

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 6),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text(label,
                  style: GoogleFonts.dmSans(
                      fontSize: 13, color: AppTheme.textPrimary)),
              Container(
                padding:
                    const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
                decoration: BoxDecoration(
                  color: AppTheme.surface,
                  borderRadius: BorderRadius.circular(6),
                  border: Border.all(color: AppTheme.border),
                ),
                child: Text(
                  '${value.round()} $unit',
                  style: GoogleFonts.dmSans(
                    fontSize: 12,
                    fontWeight: FontWeight.w500,
                    color: AppTheme.primary,
                  ),
                ),
              ),
            ],
          ),
          Slider(
            value: value,
            min: min,
            max: max,
            divisions: divisions,
            activeColor: AppTheme.primary,
            inactiveColor: AppTheme.border,
            onChanged: onChanged,
          ),
        ],
      ),
    );
  }
}

class _StepperRow extends StatelessWidget {
  final String label;
  final int value;
  final int min;
  final int max;
  final String Function(int) display;
  final Function(int) onChanged;

  const _StepperRow({
    required this.label,
    required this.value,
    required this.min,
    required this.max,
    required this.display,
    required this.onChanged,
  });

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 6),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text(label,
              style: GoogleFonts.dmSans(
                  fontSize: 13, color: AppTheme.textPrimary)),
          Row(
            children: [
              _StepBtn(
                icon: Icons.remove,
                onTap: value > min ? () => onChanged(value - 1) : null,
              ),
              Container(
                margin: const EdgeInsets.symmetric(horizontal: 8),
                padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                decoration: BoxDecoration(
                  color: AppTheme.surface,
                  borderRadius: BorderRadius.circular(6),
                  border: Border.all(color: AppTheme.border),
                ),
                child: Text(
                  display(value),
                  style: GoogleFonts.dmSans(
                      fontSize: 13,
                      fontWeight: FontWeight.w500,
                      color: AppTheme.primary),
                ),
              ),
              _StepBtn(
                icon: Icons.add,
                onTap: value < max ? () => onChanged(value + 1) : null,
              ),
            ],
          ),
        ],
      ),
    );
  }
}

class _StepBtn extends StatelessWidget {
  final IconData icon;
  final VoidCallback? onTap;
  const _StepBtn({required this.icon, required this.onTap});

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        width: 30,
        height: 30,
        decoration: BoxDecoration(
          color: onTap != null ? AppTheme.primary.withValues(alpha: 0.08) : AppTheme.surface,
          borderRadius: BorderRadius.circular(6),
          border: Border.all(color: AppTheme.border),
        ),
        child: Icon(
          icon,
          size: 16,
          color: onTap != null ? AppTheme.primary : AppTheme.textMuted,
        ),
      ),
    );
  }
}

class _CustomRulesInput extends StatefulWidget {
  final List<String> rules;
  final Function(String) onAdd;
  final Function(int) onRemove;
  const _CustomRulesInput({required this.rules, required this.onAdd, required this.onRemove});

  @override
  State<_CustomRulesInput> createState() => _CustomRulesInputState();
}

class _CustomRulesInputState extends State<_CustomRulesInput> {
  final _ctrl = TextEditingController();

  @override
  void dispose() {
    _ctrl.dispose();
    super.dispose();
  }

  void _add() {
    final text = _ctrl.text.trim();
    if (text.isEmpty) return;
    widget.onAdd(text);
    _ctrl.clear();
  }

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          children: [
            Expanded(
              child: TextField(
                controller: _ctrl,
                decoration: const InputDecoration(
                  hintText: 'Type a rule and press Add...',
                  isDense: true,
                ),
                style: GoogleFonts.dmSans(fontSize: 13),
                onSubmitted: (_) => _add(),
              ),
            ),
            const SizedBox(width: 8),
            ElevatedButton(
              onPressed: _add,
              style: ElevatedButton.styleFrom(
                padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
                minimumSize: Size.zero,
              ),
              child: const Text('Add'),
            ),
          ],
        ),
        if (widget.rules.isNotEmpty) ...[
          const SizedBox(height: 10),
          Wrap(
            spacing: 8,
            runSpacing: 8,
            children: widget.rules.asMap().entries.map((e) => Container(
              padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
              decoration: BoxDecoration(
                color: AppTheme.primary.withValues(alpha: 0.07),
                borderRadius: BorderRadius.circular(8),
                border: Border.all(color: AppTheme.primary.withValues(alpha: 0.2)),
              ),
              child: Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Flexible(
                    child: Text(e.value,
                        style: GoogleFonts.dmSans(
                            fontSize: 12, color: AppTheme.textPrimary)),
                  ),
                  const SizedBox(width: 6),
                  GestureDetector(
                    onTap: () => widget.onRemove(e.key),
                    child: const Icon(Icons.close, size: 14, color: AppTheme.textMuted),
                  ),
                ],
              ),
            )).toList(),
          ),
        ],
      ],
    );
  }
}

class _PrereqRow extends StatefulWidget {
  final Subject subject;
  const _PrereqRow({required this.subject});

  @override
  State<_PrereqRow> createState() => _PrereqRowState();
}

class _PrereqRowState extends State<_PrereqRow> {
  late TextEditingController _ctrl;

  @override
  void initState() {
    super.initState();
    _ctrl = TextEditingController(text: widget.subject.prerequisites ?? '');
  }

  @override
  void dispose() {
    _ctrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 8),
      child: Row(
        children: [
          SizedBox(
            width: 120,
            child: Text(widget.subject.name,
                style: GoogleFonts.dmSans(fontSize: 13)),
          ),
          const SizedBox(width: 8),
          Expanded(
            child: TextField(
              controller: _ctrl,
              decoration: const InputDecoration(
                hintText: 'Depends on...',
                isDense: true,
              ),
              style: GoogleFonts.dmSans(fontSize: 12),
              onEditingComplete: () {
                context.read<AppState>().updateSubject(
                      widget.subject.id,
                      widget.subject.copyWith(
                          prerequisites: _ctrl.text),
                    );
              },
            ),
          ),
        ],
      ),
    );
  }
}

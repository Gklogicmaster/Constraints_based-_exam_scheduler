// lib/screens/phase5_postexam.dart

import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:google_fonts/google_fonts.dart';
import '../providers/app_state.dart';
import '../models/models.dart';
import '../theme.dart';
import '../widgets/shared_widgets.dart';

class Phase5PostExam extends StatefulWidget {
  const Phase5PostExam({super.key});

  @override
  State<Phase5PostExam> createState() => _Phase5PostExamState();
}

class _Phase5PostExamState extends State<Phase5PostExam> {
  final Map<String, TextEditingController> _controllers = {};

  @override
  void initState() {
    super.initState();
    final subjects = context.read<AppState>().subjects;
    for (final s in subjects) {
      _controllers[s.id] = TextEditingController();
    }
  }

  @override
  void dispose() {
    for (final c in _controllers.values) {
      c.dispose();
    }
    super.dispose();
  }

  Future<void> _analyze() async {
    final state = context.read<AppState>();
    for (final s in state.subjects) {
      final text = _controllers[s.id]?.text ?? '';
      final score = double.tryParse(text);
      if (score != null) {
        state.addOrUpdateScore(ExamScore(
          subjectId: s.id,
          subjectName: s.name,
          score: score.clamp(0, 100),
          examDate: DateTime.now(),
        ));
      }
    }
    await state.analyzeAndReschedule();
  }

  @override
  Widget build(BuildContext context) {
    final state = context.watch<AppState>();

    return SingleChildScrollView(
      padding: const EdgeInsets.all(16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Container(
                width: 40,
                height: 40,
                decoration: BoxDecoration(
                  color: AppTheme.surface,
                  borderRadius: BorderRadius.circular(20),
                  border: Border.all(color: AppTheme.border),
                ),
                child: const Center(
                    child: Text('📊', style: TextStyle(fontSize: 18))),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text('Post-exam analysis',
                        style: GoogleFonts.dmSans(
                            fontSize: 16, fontWeight: FontWeight.w600)),
                    Text(
                        'Enter your scores and get an auto-adjusted schedule',
                        style: GoogleFonts.dmSans(
                            fontSize: 12,
                            color: AppTheme.textSecondary)),
                  ],
                ),
              ),
            ],
          ),
          const SizedBox(height: 16),

          // Score inputs
          AppCard(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const SectionTitle('Exam scores'),
                ...state.subjects.asMap().entries.map((e) {
                  final idx = e.key;
                  final subject = e.value;
                  final ctrl = _controllers[subject.id]!;
                  final scoreText = ctrl.text;
                  final score = double.tryParse(scoreText);

                  String perfLabel = '—';
                  Color perfColor = AppTheme.textMuted;
                  Color perfBg = AppTheme.surface;

                  if (score != null) {
                    if (score < 50) {
                      perfLabel = 'Needs focus';
                      perfColor = const Color(0xFFA32D2D);
                      perfBg = const Color(0xFFFCEBEB);
                    } else if (score < 75) {
                      perfLabel = 'Extra revision';
                      perfColor = const Color(0xFF854F0B);
                      perfBg = const Color(0xFFFAEEDA);
                    } else {
                      perfLabel = 'Light revision';
                      perfColor = const Color(0xFF3B6D11);
                      perfBg = const Color(0xFFEAF3DE);
                    }
                  }

                  return Padding(
                    padding: const EdgeInsets.only(bottom: 12),
                    child: Row(
                      children: [
                        SubjectDot(colorIndex: idx),
                        const SizedBox(width: 8),
                        Expanded(
                          flex: 3,
                          child: Text(subject.name,
                              style: GoogleFonts.dmSans(fontSize: 13)),
                        ),
                        SizedBox(
                          width: 80,
                          child: TextField(
                            controller: ctrl,
                            keyboardType:
                                const TextInputType.numberWithOptions(
                                    decimal: true),
                            decoration: const InputDecoration(
                              hintText: '0–100',
                              isDense: true,
                              suffixText: '%',
                            ),
                            style: GoogleFonts.dmSans(fontSize: 13),
                            onChanged: (_) => setState(() {}),
                          ),
                        ),
                        const SizedBox(width: 8),
                        Container(
                          padding: const EdgeInsets.symmetric(
                              horizontal: 8, vertical: 3),
                          decoration: BoxDecoration(
                            color: perfBg,
                            borderRadius: BorderRadius.circular(6),
                          ),
                          child: Text(
                            perfLabel,
                            style: GoogleFonts.dmSans(
                                fontSize: 11,
                                fontWeight: FontWeight.w500,
                                color: perfColor),
                          ),
                        ),
                      ],
                    ),
                  );
                }),
              ],
            ),
          ),

          // Visual score breakdown
          if (state.examScores.isNotEmpty) ...[
            AppCard(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const SectionTitle('Score breakdown'),
                  ...state.examScores.map((score) {
                    final pct = score.score / 100;
                    return Padding(
                      padding: const EdgeInsets.only(bottom: 10),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Row(
                            mainAxisAlignment:
                                MainAxisAlignment.spaceBetween,
                            children: [
                              Text(score.subjectName,
                                  style: GoogleFonts.dmSans(
                                      fontSize: 13)),
                              Text(
                                '${score.score.round()}%',
                                style: GoogleFonts.dmSans(
                                  fontSize: 13,
                                  fontWeight: FontWeight.w500,
                                  color: score.performanceColor,
                                ),
                              ),
                            ],
                          ),
                          const SizedBox(height: 4),
                          AppProgressBar(
                            value: pct,
                            color: score.performanceColor,
                          ),
                        ],
                      ),
                    );
                  }),
                ],
              ),
            ),
          ],

          // Analyze button
          SizedBox(
            width: double.infinity,
            child: ElevatedButton.icon(
              onPressed:
                  state.isAnalyzing ? null : _analyze,
              icon: state.isAnalyzing
                  ? const SizedBox(
                      width: 16,
                      height: 16,
                      child: CircularProgressIndicator(
                          strokeWidth: 2, color: Colors.white))
                  : const Icon(Icons.auto_fix_high, size: 18),
              label: Text(state.isAnalyzing
                  ? 'Analyzing...'
                  : 'Analyze & re-schedule'),
            ),
          ),

          // AI Analysis result
          if (state.aiAnalysis != null) ...[
            const SizedBox(height: 16),
            AppCard(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      Container(
                        width: 28,
                        height: 28,
                        decoration: BoxDecoration(
                          color: const Color(0xFFEEEDFE),
                          borderRadius: BorderRadius.circular(14),
                        ),
                        child: const Center(
                            child: Text('✨',
                                style: TextStyle(fontSize: 14))),
                      ),
                      const SizedBox(width: 8),
                      Text('AI recommendation',
                          style: GoogleFonts.dmSans(
                              fontSize: 13,
                              fontWeight: FontWeight.w500)),
                    ],
                  ),
                  const SizedBox(height: 10),
                  Text(
                    state.aiAnalysis!,
                    style: GoogleFonts.dmSans(
                      fontSize: 13,
                      color: AppTheme.textSecondary,
                      height: 1.6,
                    ),
                  ),
                ],
              ),
            ),

            // Updated priorities
            AppCard(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const SectionTitle('Updated priorities'),
                  Wrap(
                    spacing: 8,
                    runSpacing: 8,
                    children: state.subjects
                        .map((s) => Container(
                              padding: const EdgeInsets.symmetric(
                                  horizontal: 10, vertical: 7),
                              decoration: BoxDecoration(
                                color: AppTheme.surface,
                                borderRadius: BorderRadius.circular(8),
                                border:
                                    Border.all(color: AppTheme.border),
                              ),
                              child: Row(
                                mainAxisSize: MainAxisSize.min,
                                children: [
                                  Text(s.name,
                                      style: GoogleFonts.dmSans(
                                          fontSize: 13)),
                                  const SizedBox(width: 6),
                                  PriorityBadge(s.priority),
                                ],
                              ),
                            ))
                        .toList(),
                  ),
                ],
              ),
            ),

            SizedBox(
              width: double.infinity,
              child: ElevatedButton.icon(
                onPressed: () {
                  context.read<AppState>().goToPhase(2);
                  context.read<AppState>().generateSchedules();
                },
                icon: const Icon(Icons.refresh, size: 18),
                label: const Text('Generate new schedules →'),
              ),
            ),
          ],
          const SizedBox(height: 16),
        ],
      ),
    );
  }
}

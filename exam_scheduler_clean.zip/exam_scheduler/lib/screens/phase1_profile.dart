// lib/screens/phase1_profile.dart

import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:google_fonts/google_fonts.dart';
import '../providers/app_state.dart';
import '../models/models.dart';
import '../theme.dart';
import '../widgets/shared_widgets.dart';

class Phase1Profile extends StatelessWidget {
  const Phase1Profile({super.key});

  @override
  Widget build(BuildContext context) {
    return SingleChildScrollView(
      padding: const EdgeInsets.all(16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          _PhaseHeader(
            icon: '📚',
            title: 'Student profile',
            subtitle:
                'Add your subjects, exam dates, and available study hours',
          ),
          const SizedBox(height: 16),
          const _SubjectsCard(),
          const _AvailabilityCard(),
          const _BlockedDatesCard(),
          const SizedBox(height: 8),
          SizedBox(
            width: double.infinity,
            child: ElevatedButton(
              onPressed: () =>
                  context.read<AppState>().goToPhase(1),
              child: const Text('Next: set constraints →'),
            ),
          ),
          const SizedBox(height: 16),
        ],
      ),
    );
  }
}

class _PhaseHeader extends StatelessWidget {
  final String icon;
  final String title;
  final String subtitle;
  const _PhaseHeader(
      {required this.icon, required this.title, required this.subtitle});

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        Container(
          width: 40,
          height: 40,
          decoration: BoxDecoration(
            color: AppTheme.surface,
            borderRadius: BorderRadius.circular(20),
            border: Border.all(color: AppTheme.border),
          ),
          child: Center(child: Text(icon, style: const TextStyle(fontSize: 18))),
        ),
        const SizedBox(width: 12),
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(title,
                  style: GoogleFonts.dmSans(
                      fontSize: 16, fontWeight: FontWeight.w600)),
              Text(subtitle,
                  style: GoogleFonts.dmSans(
                      fontSize: 12, color: AppTheme.textSecondary)),
            ],
          ),
        ),
      ],
    );
  }
}

class _SubjectsCard extends StatelessWidget {
  const _SubjectsCard();

  void _addSubject(BuildContext context) {
    final ctrl = TextEditingController();
    showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        title: Text('Add subject',
            style: GoogleFonts.dmSans(fontWeight: FontWeight.w600)),
        content: TextField(
          controller: ctrl,
          autofocus: true,
          decoration: const InputDecoration(hintText: 'Subject name'),
        ),
        actions: [
          TextButton(
              onPressed: () => Navigator.pop(ctx),
              child: const Text('Cancel')),
          ElevatedButton(
              onPressed: () {
                if (ctrl.text.isNotEmpty) {
                  context.read<AppState>().addSubject(ctrl.text);
                  Navigator.pop(ctx);
                }
              },
              child: const Text('Add')),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final subjects = context.watch<AppState>().subjects;

    return AppCard(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const SectionTitle('Subjects'),
          ...subjects.asMap().entries.map(
                (e) => _SubjectRow(subject: e.value, index: e.key),
              ),
          const SizedBox(height: 8),
          OutlinedButton.icon(
            onPressed: () => _addSubject(context),
            icon: const Icon(Icons.add, size: 16),
            label: const Text('Add subject'),
          ),
        ],
      ),
    );
  }
}

class _SubjectRow extends StatefulWidget {
  final Subject subject;
  final int index;
  const _SubjectRow({required this.subject, required this.index});

  @override
  State<_SubjectRow> createState() => _SubjectRowState();
}

class _SubjectRowState extends State<_SubjectRow> {
  late TextEditingController _nameCtrl;

  @override
  void initState() {
    super.initState();
    _nameCtrl = TextEditingController(text: widget.subject.name);
  }

  @override
  void dispose() {
    _nameCtrl.dispose();
    super.dispose();
  }

  void _save() {
    final state = context.read<AppState>();
    state.updateSubject(
      widget.subject.id,
      widget.subject.copyWith(
        name: _nameCtrl.text,
      ),
    );
  }

  Future<void> _pickDate() async {
    final picked = await showDatePicker(
      context: context,
      initialDate:
          widget.subject.examDate ?? DateTime.now().add(const Duration(days: 30)),
      firstDate: DateTime.now(),
      lastDate: DateTime.now().add(const Duration(days: 365)),
    );
    if (picked != null) {
      context.read<AppState>().updateSubject(
            widget.subject.id,
            widget.subject.copyWith(examDate: picked),
          );
    }
  }

  @override
  Widget build(BuildContext context) {
    final colorIdx =
        widget.index % AppTheme.subjectColors.length;
    final subjectColor = AppTheme.subjectColors[colorIdx];
    final subjectBg = AppTheme.subjectBgColors[colorIdx];

    return Container(
      margin: const EdgeInsets.only(bottom: 10),
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: subjectBg.withValues(alpha: 0.4),
        borderRadius: BorderRadius.circular(10),
        border: Border.all(
            color: subjectColor.withValues(alpha: 0.3), width: 0.5),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Expanded(
                child: TextField(
                  controller: _nameCtrl,
                  onEditingComplete: _save,
                  decoration: const InputDecoration(
                    hintText: 'Subject name',
                    isDense: true,
                  ),
                  style: GoogleFonts.dmSans(
                      fontSize: 14, fontWeight: FontWeight.w500),
                ),
              ),
              const SizedBox(width: 8),
              IconButton(
                icon: const Icon(Icons.delete_outline, size: 18),
                color: AppTheme.textMuted,
                onPressed: () =>
                    context.read<AppState>().removeSubject(widget.subject.id),
                padding: EdgeInsets.zero,
                constraints: const BoxConstraints(),
              ),
            ],
          ),
          const SizedBox(height: 10),
          Wrap(
            spacing: 10,
            runSpacing: 8,
            children: [
              // Proficiency
              _DropdownField<int>(
                label: 'Proficiency',
                value: widget.subject.proficiency,
                items: List.generate(5, (i) => i + 1),
                labelBuilder: (v) => '$v/5',
                onChanged: (v) => context.read<AppState>().updateSubject(
                      widget.subject.id,
                      widget.subject.copyWith(proficiency: v),
                    ),
              ),
              // Priority
              _DropdownField<Priority>(
                label: 'Priority',
                value: widget.subject.priority,
                items: Priority.values,
                labelBuilder: (v) => v.name[0].toUpperCase() + v.name.substring(1),
                onChanged: (v) => context.read<AppState>().updateSubject(
                      widget.subject.id,
                      widget.subject.copyWith(priority: v),
                    ),
              ),
            ],
          ),
          const SizedBox(height: 8),
          GestureDetector(
            onTap: _pickDate,
            child: Container(
              padding:
                  const EdgeInsets.symmetric(horizontal: 10, vertical: 7),
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(8),
                border: Border.all(color: AppTheme.border),
              ),
              child: Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  const Icon(Icons.event, size: 14,
                      color: AppTheme.textSecondary),
                  const SizedBox(width: 6),
                  Text(
                    widget.subject.examDate != null
                        ? 'Exam: ${_fmt(widget.subject.examDate!)}'
                        : 'Set exam date',
                    style: GoogleFonts.dmSans(
                      fontSize: 12,
                      color: widget.subject.examDate != null
                          ? AppTheme.textPrimary
                          : AppTheme.textMuted,
                    ),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  String _fmt(DateTime d) =>
      '${d.day}/${d.month}/${d.year}';
}

class _DropdownField<T> extends StatelessWidget {
  final String label;
  final T value;
  final List<T> items;
  final String Function(T) labelBuilder;
  final Function(T) onChanged;

  const _DropdownField({
    required this.label,
    required this.value,
    required this.items,
    required this.labelBuilder,
    required this.onChanged,
  });

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(label,
            style: GoogleFonts.dmSans(
                fontSize: 10, color: AppTheme.textMuted)),
        const SizedBox(height: 2),
        Container(
          padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.circular(8),
            border: Border.all(color: AppTheme.border),
          ),
          child: DropdownButton<T>(
            value: value,
            isDense: true,
            underline: const SizedBox.shrink(),
            style: GoogleFonts.dmSans(
                fontSize: 12, color: AppTheme.textPrimary),
            items: items
                .map((item) => DropdownMenuItem<T>(
                      value: item,
                      child: Text(labelBuilder(item)),
                    ))
                .toList(),
            onChanged: (v) {
              if (v != null) onChanged(v);
            },
          ),
        ),
      ],
    );
  }
}

class _AvailabilityCard extends StatelessWidget {
  const _AvailabilityCard();

  @override
  Widget build(BuildContext context) {
    final slots = context.watch<AppState>().availableSlots;

    return AppCard(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const SectionTitle('Weekly availability'),
          ...AppConsts.weekdays.map((day) {
            final daySlots = slots[day] ?? [];
            return _DayRow(day: day, slots: daySlots);
          }),
        ],
      ),
    );
  }
}

class _DayRow extends StatelessWidget {
  final String day;
  final List<TimeSlot> slots;
  const _DayRow({required this.day, required this.slots});

  Future<void> _addSlot(BuildContext context) async {
    TimeOfDay start = const TimeOfDay(hour: 9, minute: 0);
    TimeOfDay end = const TimeOfDay(hour: 13, minute: 0);

    final startPicked = await showTimePicker(
        context: context, initialTime: start);
    if (startPicked == null || !context.mounted) return;
    start = startPicked;

    final endPicked = await showTimePicker(
        context: context, initialTime: end);
    if (endPicked == null || !context.mounted) return;
    end = endPicked;

    context
        .read<AppState>()
        .addSlot(day, TimeSlot(day: day, startTime: start, endTime: end));
  }

  String _fmtTime(TimeOfDay t) {
    final h = t.hourOfPeriod == 0 ? 12 : t.hourOfPeriod;
    final m = t.minute.toString().padLeft(2, '0');
    return '$h:$m ${t.period.name}';
  }

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 4),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          SizedBox(
            width: 80,
            child: Text(day.substring(0, 3),
                style: GoogleFonts.dmSans(
                    fontSize: 13, color: AppTheme.textSecondary)),
          ),
          Expanded(
            child: Wrap(
              spacing: 6,
              runSpacing: 6,
              children: [
                ...slots.asMap().entries.map((e) => GestureDetector(
                      onLongPress: () =>
                          context.read<AppState>().removeSlot(day, e.key),
                      child: Container(
                        padding: const EdgeInsets.symmetric(
                            horizontal: 8, vertical: 4),
                        decoration: BoxDecoration(
                          color: const Color(0xFFE6F1FB),
                          borderRadius: BorderRadius.circular(6),
                        ),
                        child: Text(
                          '${_fmtTime(e.value.startTime)} – ${_fmtTime(e.value.endTime)}',
                          style: GoogleFonts.dmSans(
                              fontSize: 11,
                              color: const Color(0xFF185FA5)),
                        ),
                      ),
                    )),
                GestureDetector(
                  onTap: () => _addSlot(context),
                  child: Container(
                    padding: const EdgeInsets.symmetric(
                        horizontal: 8, vertical: 4),
                    decoration: BoxDecoration(
                      border: Border.all(
                          color: AppTheme.border, style: BorderStyle.solid),
                      borderRadius: BorderRadius.circular(6),
                    ),
                    child: Text('+',
                        style: GoogleFonts.dmSans(
                            fontSize: 13,
                            color: AppTheme.textMuted)),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class _BlockedDatesCard extends StatelessWidget {
  const _BlockedDatesCard();

  Future<void> _pickDate(BuildContext context) async {
    final picked = await showDatePicker(
      context: context,
      initialDate: DateTime.now(),
      firstDate: DateTime.now(),
      lastDate: DateTime.now().add(const Duration(days: 365)),
    );
    if (picked != null && context.mounted) {
      context.read<AppState>().addBlockedDate(picked);
    }
  }

  String _fmt(DateTime d) =>
      '${d.day}/${d.month}/${d.year}';

  @override
  Widget build(BuildContext context) {
    final blocked = context.watch<AppState>().blockedDates;

    return AppCard(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const SectionTitle('Blocked dates'),
          Wrap(
            spacing: 8,
            runSpacing: 8,
            children: [
              ...blocked.map((d) => GestureDetector(
                    onTap: () =>
                        context.read<AppState>().removeBlockedDate(d),
                    child: Container(
                      padding: const EdgeInsets.symmetric(
                          horizontal: 10, vertical: 5),
                      decoration: BoxDecoration(
                        color: const Color(0xFFFCEBEB),
                        borderRadius: BorderRadius.circular(6),
                      ),
                      child: Row(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          Text(_fmt(d),
                              style: GoogleFonts.dmSans(
                                  fontSize: 12,
                                  color: const Color(0xFFA32D2D))),
                          const SizedBox(width: 4),
                          const Icon(Icons.close,
                              size: 12,
                              color: Color(0xFFA32D2D)),
                        ],
                      ),
                    ),
                  )),
              GestureDetector(
                onTap: () => _pickDate(context),
                child: Container(
                  padding: const EdgeInsets.symmetric(
                      horizontal: 10, vertical: 5),
                  decoration: BoxDecoration(
                    border: Border.all(color: AppTheme.border),
                    borderRadius: BorderRadius.circular(6),
                  ),
                  child: Text('+ block a date',
                      style: GoogleFonts.dmSans(
                          fontSize: 12,
                          color: AppTheme.textSecondary)),
                ),
              ),
            ],
          ),
          if (blocked.isEmpty)
            Padding(
              padding: const EdgeInsets.only(top: 4),
              child: Text(
                'No blocked dates. Tap to add holidays or rest days.',
                style: GoogleFonts.dmSans(
                    fontSize: 12, color: AppTheme.textMuted),
              ),
            ),
        ],
      ),
    );
  }
}
